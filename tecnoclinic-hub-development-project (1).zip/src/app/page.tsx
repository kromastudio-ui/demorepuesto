import TecnoClinicApp from "@/app/tecno-clinic-app";
import { getDashboardData } from "@/lib/app-data";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const initialData = await getDashboardData();
  return <TecnoClinicApp initialData={initialData} />;
}
