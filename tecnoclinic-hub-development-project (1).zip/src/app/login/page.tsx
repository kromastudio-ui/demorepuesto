"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { signIn } from "next-auth/react";
import { Activity, ArrowLeft, Eye, EyeOff, LockKeyhole, Mail } from "lucide-react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const result = await signIn("credentials", {
      email,
      password,
      redirect: false,
      callbackUrl: "/",
    });
    setBusy(false);
    if (result?.error) {
      setError("No pudimos validar tus credenciales. Verifica tus datos o consulta al administrador.");
      return;
    }
    window.location.href = result?.url || "/";
  }

  return (
    <main className="login-shell">
      <div className="login-brand-panel">
        <div className="login-brand">
          <div className="brand-mark brand-mark-large"><Activity size={25} strokeWidth={2.4} /></div>
          <div><strong>TECNOCLINIC</strong><span>HUB DE OPERACIONES</span></div>
        </div>
        <div className="login-hero-copy">
          <span className="eyebrow-light">SERVICIO CONFIABLE, DE PRINCIPIO A FIN</span>
          <h1>Todo tu taller.<br /><span>En un solo lugar.</span></h1>
          <p>Clientes, vehículos, citas y conversaciones de Tecnoclinic, organizados para que cada visita cuente.</p>
        </div>
        <div className="login-panel-footer"><span className="login-dot" /> Maripérez, Caracas <span>·</span> America/Caracas</div>
      </div>
      <div className="login-form-panel">
        <Link href="/" className="back-link"><ArrowLeft size={15} /> Volver al tablero</Link>
        <div className="login-form-wrap">
          <div className="login-mobile-mark"><div className="brand-mark"><Activity size={21} /></div><strong>TecnoClinic Hub</strong></div>
          <span className="form-kicker">ACCESO DEL EQUIPO</span>
          <h2>Te damos la bienvenida</h2>
          <p className="login-subtitle">Ingresa con las credenciales de tu cuenta de Tecnoclinic.</p>
          <form onSubmit={submit} className="login-form">
            <label htmlFor="email">Correo electrónico</label>
            <div className="login-input"><Mail size={17} /><input id="email" type="email" autoComplete="username" placeholder="nombre@tecnoclinic.com" required value={email} onChange={(event) => setEmail(event.target.value)} /></div>
            <label htmlFor="password">Contraseña</label>
            <div className="login-input"><LockKeyhole size={17} /><input id="password" type={showPassword ? "text" : "password"} autoComplete="current-password" placeholder="Ingresa tu contraseña" required value={password} onChange={(event) => setPassword(event.target.value)} /><button type="button" className="password-toggle" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}>{showPassword ? <EyeOff size={16} /> : <Eye size={16} />}</button></div>
            {error && <p className="login-error" role="alert">{error}</p>}
            <button type="submit" className="login-submit" disabled={busy}>{busy ? <span className="spinner" /> : null}{busy ? "Validando…" : "Iniciar sesión"}</button>
          </form>
          <div className="login-help"><span>¿Necesitas acceso?</span><p>Solicita una cuenta al administrador. Perfiles disponibles: Administrador y Técnico / Asesor.</p></div>
        </div>
        <div className="login-legal">Tecnoclinic Repuestos <span>·</span> RIF J-311592024</div>
      </div>
    </main>
  );
}
