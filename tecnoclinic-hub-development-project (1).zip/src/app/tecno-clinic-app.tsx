"use client";

import NextImage from "next/image";
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  ArrowUpRight,
  Bell,
  Bot,
  CalendarCheck,
  CalendarClock,
  CalendarDays,
  CalendarPlus,
  CarFront,
  Check,
  CheckCheck,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  ClipboardList,
  Clock3,
  Copy,
  Download,
  Ellipsis,
  Filter,
  Gauge,
  Headphones,
  Inbox as InboxIcon,
  LayoutDashboard,
  List,
  LoaderCircle,
  MapPin,
  Menu,
  MessageCircle,
  MessageSquare,
  MoreHorizontal,
  Package,
  Paperclip,
  Phone,
  Plus,
  QrCode,
  Search,
  Send,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Tag,
  Timer,
  TrendingUp,
  UserCog,
  UserPlus,
  Users,
  Wrench,
  X,
  Zap,
  FileText,
  CircleDollarSign,
  ScanLine,
  Link2,
  type LucideIcon,
} from "lucide-react";
import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type FormEvent,
  type KeyboardEvent,
  type ReactNode,
} from "react";
import type {
  AppointmentRecord,
  ConversationRecord,
  CustomerRecord,
  DashboardData,
  MessageRecord,
  PartRecord,
  VehicleRecord,
  WorkOrderRecord,
  WorkOrderStatus,
} from "@/lib/types";

const TIME_ZONE = "America/Caracas";

type ViewKey = "dashboard" | "tasks" | "calendar" | "clients" | "vehicles" | "orders" | "inventory" | "inbox" | "assistant" | "templates" | "settings";
type Toast = { message: string; kind: "success" | "error"; id: number };
type WhatsAppSnapshot = { status: "disconnected" | "connecting" | "qr" | "connected"; qrDataUrl: string | null; phoneNumber: string | null; connected: boolean };

const statusColumns: { id: WorkOrderStatus; label: string; dot: string; badge: string }[] = [
  { id: "por_cotizar", label: "Por cotizar", dot: "#d8a44a", badge: "s-amber" },
  { id: "cita_agendada", label: "Cita agendada", dot: "#6b90d1", badge: "s-blue" },
  { id: "diagnostico", label: "En diagnóstico", dot: "#9378cf", badge: "s-purple" },
  { id: "esperando_repuesto", label: "Esperando repuesto", dot: "#e1a046", badge: "s-amber" },
  { id: "listo_entrega", label: "Listo para entrega", dot: "#21a97a", badge: "s-green" },
  { id: "entregado", label: "Entregado / facturado", dot: "#8995a5", badge: "s-slate" },
];

const services = [
  "Limpieza de inyectores",
  "Escáner computarizado",
  "Mecánica rápida",
  "Diagnóstico de motor",
  "Cambio de aceite",
  "Cotización de repuestos",
];

const avatarClasses = ["avatar-sage", "avatar-blue", "avatar-peach", "avatar-lavender", "avatar-sand", "avatar-rose", "avatar-mint", "avatar-slate"];

function initials(name: string) {
  return name
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("") || "TC";
}

function avatarClass(name: string) {
  const total = Array.from(name).reduce((value, character) => value + character.charCodeAt(0), 0);
  return avatarClasses[total % avatarClasses.length];
}

function caracasDateKey(date: Date) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function shiftDateKey(key: string, days: number) {
  const [year, month, day] = key.split("-").map(Number);
  const shifted = new Date(Date.UTC(year, month - 1, day + days, 12));
  return caracasDateKey(shifted);
}

function caracasInputValue() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}T${values.hour}:${values.minute}`;
}

function caracasIso(value: string) {
  return new Date(`${value}:00-04:00`).toISOString();
}

function formatCaracasTime(value: string | Date) {
  return new Intl.DateTimeFormat("es-VE", { timeZone: TIME_ZONE, hour: "numeric", minute: "2-digit" }).format(new Date(value));
}

function formatCaracasDate(value: string | Date, options: Intl.DateTimeFormatOptions = { day: "numeric", month: "short" }) {
  return new Intl.DateTimeFormat("es-VE", { timeZone: TIME_ZONE, ...options }).format(new Date(value));
}

function formatRelative(value: string) {
  const minutes = Math.round((new Date(value).getTime() - Date.now()) / 60_000);
  const formatter = new Intl.RelativeTimeFormat("es", { numeric: "auto" });
  if (Math.abs(minutes) < 60) return formatter.format(minutes, "minute");
  const hours = Math.round(minutes / 60);
  if (Math.abs(hours) < 24) return formatter.format(hours, "hour");
  return formatter.format(Math.round(hours / 24), "day");
}

function formatMoney(value: number) {
  return new Intl.NumberFormat("es-VE", { style: "currency", currency: "USD", maximumFractionDigits: 2 }).format(value);
}

function statusMeta(status: WorkOrderStatus) {
  return statusColumns.find((column) => column.id === status) ?? statusColumns[0];
}

function Avatar({ name, round = false, small = false }: { name: string; round?: boolean; small?: boolean }) {
  return <span className={`person-avatar ${avatarClass(name)}${round ? " round" : ""}`} style={small ? { width: 25, height: 25, fontSize: 7.5 } : undefined}>{initials(name)}</span>;
}

function StatusBadge({ status }: { status: WorkOrderStatus }) {
  const meta = statusMeta(status);
  return <span className={`status-pill ${meta.badge}`}><i className="status-mini-dot" />{meta.label}</span>;
}

function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return (
    <div className="page-heading">
      <div className="page-heading-copy">
        <div className="eyebrow"><i className="eyebrow-dot" />{eyebrow}</div>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {action ? <div className="heading-actions">{action}</div> : null}
    </div>
  );
}

function MetricCard({ icon: Icon, tone, label, value, note, trend }: { icon: LucideIcon; tone: "green" | "blue" | "amber" | "violet"; label: string; value: string | number; note?: string; trend?: string }) {
  return (
    <div className="metric-card">
      <div className={`metric-icon ${tone}`}><Icon size={17} strokeWidth={1.9} /></div>
      <div className="metric-copy"><span>{label}</span><strong>{value}</strong>{note ? <small>{note}</small> : null}</div>
      {trend ? <span className="metric-trend"><TrendingUp size={12} />{trend}</span> : null}
    </div>
  );
}

function Modal({ children, title, description, icon: Icon, onClose, wide = false }: { children: ReactNode; title: string; description: string; icon: LucideIcon; onClose: () => void; wide?: boolean }) {
  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className={`modal-card${wide ? " wide" : ""}`} role="dialog" aria-modal="true" aria-label={title}>
        <header className="modal-header">
          <div className="modal-heading"><div className="modal-heading-icon"><Icon size={17} /></div><div><h2>{title}</h2><p>{description}</p></div></div>
          <button type="button" className="modal-close" onClick={onClose} aria-label="Cerrar"><X size={16} /></button>
        </header>
        <div className="modal-body">{children}</div>
      </section>
    </div>
  );
}

function WorkOrderCard({ order, onMove, onOpen, onDragStart }: { order: WorkOrderRecord; onMove: (id: number, status: WorkOrderStatus) => void; onOpen: (order: WorkOrderRecord) => void; onDragStart: (id: number) => void }) {
  return (
    <article
      className="kanban-card"
      draggable
      onDragStart={() => onDragStart(order.id)}
      onClick={() => onOpen(order)}
      aria-label={`Orden ${order.code}, ${order.clientName}`}
    >
      <div className="card-code-row"><span className="card-code">{order.code}</span><button className="card-menu" type="button" aria-label="Opciones de orden" onClick={(event) => { event.stopPropagation(); onOpen(order); }}><Ellipsis size={15} /></button></div>
      <div className="card-client-row"><Avatar name={order.clientName} /><div className="card-client-copy"><strong>{order.clientName}</strong><span>{order.service}</span></div></div>
      <div className="card-divider" />
      <div className="vehicle-line"><CarFront size={13} /><span className="vehicle-label">{order.vehicle}</span><span className="plate-chip">{order.plate}</span></div>
      <div className="card-description">{order.description || "Servicio solicitado por el cliente."}</div>
      {order.priority === "alta" ? <div className="priority-label high"><Zap size={10} fill="currentColor" /> Prioridad alta</div> : null}
      <div className="card-footer"><Clock3 size={11} />{formatRelative(order.updatedAt)}<span className="footer-spacer" /><span className="tech-avatar">{initials(order.technician)}</span><span className="tech-name">{order.technician}</span></div>
      <select
        className="sr-only"
        aria-label={`Cambiar estado ${order.code}`}
        value={order.status}
        onChange={(event) => onMove(order.id, event.target.value as WorkOrderStatus)}
        onClick={(event) => event.stopPropagation()}
      >
        {statusColumns.map((column) => <option key={column.id} value={column.id}>{column.label}</option>)}
      </select>
    </article>
  );
}

const navGroups: { label: string; items: { key: ViewKey; label: string; icon: LucideIcon; badge?: "tasks" | "inbox" | "stock" | "ai" }[] }[] = [
  { label: "Principal", items: [
    { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { key: "tasks", label: "Tareas pendientes", icon: ClipboardList, badge: "tasks" },
    { key: "calendar", label: "Calendario de citas", icon: CalendarDays },
  ] },
  { label: "Operaciones · Taller", items: [
    { key: "clients", label: "Clientes", icon: Users },
    { key: "vehicles", label: "Vehículos", icon: CarFront },
    { key: "orders", label: "Órdenes de trabajo", icon: Wrench },
    { key: "inventory", label: "Inventario de repuestos", icon: Package, badge: "stock" },
  ] },
  { label: "Comunicación", items: [
    { key: "inbox", label: "Bandeja WhatsApp", icon: MessageCircle, badge: "inbox" },
    { key: "assistant", label: "Asistente IA", icon: Sparkles, badge: "ai" },
    { key: "templates", label: "Plantillas de mensajes", icon: FileText },
  ] },
];

export default function TecnoClinicApp({ initialData }: { initialData: DashboardData }) {
  const [data, setData] = useState(initialData);
  const [view, setView] = useState<ViewKey>("orders");
  const [search, setSearch] = useState("");
  const [orderMode, setOrderMode] = useState<"kanban" | "list">("kanban");
  const [orderFilter, setOrderFilter] = useState<"all" | "mine" | "priority">("all");
  const [filterOpen, setFilterOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [clientModalOpen, setClientModalOpen] = useState(false);
  const [appointmentModalOpen, setAppointmentModalOpen] = useState(false);
  const [appointmentSource, setAppointmentSource] = useState<"calendar" | "assistant">("calendar");
  const [partModalOpen, setPartModalOpen] = useState(false);
  const [focusedOrder, setFocusedOrder] = useState<WorkOrderRecord | null>(null);
  const [toast, setToast] = useState<Toast | null>(null);
  const [busy, setBusy] = useState(false);
  const [draggingOrderId, setDraggingOrderId] = useState<number | null>(null);
  const [selectedConversationId, setSelectedConversationId] = useState<number | null>(initialData.conversations[0]?.id ?? null);
  const [inboxSearch, setInboxSearch] = useState("");
  const [inboxFilter, setInboxFilter] = useState<"all" | "unread" | "mine">("all");
  const [inboxDraft, setInboxDraft] = useState("");
  const [assistantDraft, setAssistantDraft] = useState("");
  const [assistantBusy, setAssistantBusy] = useState(false);
  const [assistantMessages, setAssistantMessages] = useState<{ role: "assistant" | "user"; body: string; at: string }[]>([
    { role: "assistant", body: "¡Hola! Soy el asistente virtual de Tecnoclinic. Puedo consultar disponibilidad de repuestos, orientarte sobre nuestros servicios y ayudarte a coordinar una cita en Maripérez. ¿Qué necesita tu vehículo?", at: new Date().toISOString() },
  ]);
  const [whatsAppStatus, setWhatsAppStatus] = useState<WhatsAppSnapshot>({ status: "disconnected", qrDataUrl: null, phoneNumber: null, connected: false });
  const [connectionModalOpen, setConnectionModalOpen] = useState(false);
  const [calendarDate, setCalendarDate] = useState(() => caracasDateKey(new Date()));
  const [taskDone, setTaskDone] = useState<number[]>([]);
  const [tasks, setTasks] = useState([
    { id: 1, title: "Confirmar llegada de bujías iridium NGK", detail: "Pedido para Sofía Marcano · TC-0246", due: "Hoy, 11:00 a. m.", kind: "Repuesto" },
    { id: 2, title: "Enviar cotización del tren delantero", detail: "Paula Berrizbeitia · Chevrolet Cruze", due: "Hoy, 12:30 p. m.", kind: "Cotización" },
    { id: 3, title: "Llamar a proveedor por filtro PF46E", detail: "Inventario bajo · ACDelco", due: "Hoy, 2:00 p. m.", kind: "Inventario" },
    { id: 4, title: "Revisar órdenes listas para entrega", detail: "Pendiente de confirmación al cliente", due: "Hoy, 4:00 p. m.", kind: "Taller" },
  ]);
  const [automationSettings, setAutomationSettings] = useState([
    { id: "ai_whatsapp", title: "Asistente IA en WhatsApp", description: "Responde consultas frecuentes y deriva a un asesor cuando hace falta.", active: false },
    { id: "appointment_reminders", title: "Recordatorios de citas", description: "Prepara recordatorios para confirmar las visitas del día siguiente.", active: true },
    { id: "quote_followup", title: "Seguimiento de cotizaciones", description: "Crea una tarea si una cotización queda pendiente por más de 24 horas.", active: true },
  ]);
  const [orderDraft, setOrderDraft] = useState({ name: "", phone: "", email: "", make: "", model: "", year: "", plate: "", service: "", description: "", priority: "normal", status: "por_cotizar" as WorkOrderStatus, amount: "" });
  const [clientDraft, setClientDraft] = useState({ name: "", phone: "", email: "", notes: "" });
  const [appointmentDraft, setAppointmentDraft] = useState({ name: "", phone: "", email: "", make: "", model: "", year: "", plate: "", service: services[0], startsAt: caracasInputValue(), notes: "" });
  const [partDraft, setPartDraft] = useState({ sku: "", name: "", brand: "ACDelco", category: "Lubricantes", stock: "0", minimumStock: "3", price: "", supplier: "" });
  const searchRef = useRef<HTMLInputElement>(null);
  const inboxDraftRef = useRef<HTMLTextAreaElement>(null);
  const assistantDraftRef = useRef<HTMLTextAreaElement>(null);

  const notify = (message: string, kind: Toast["kind"] = "success") => {
    const id = Date.now();
    setToast({ message, kind, id });
    window.setTimeout(() => setToast((current) => current?.id === id ? null : current), 3400);
  };

  useEffect(() => {
    const onShortcut = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        searchRef.current?.focus();
      }
      if (event.key === "Escape") {
        setOrderModalOpen(false);
        setClientModalOpen(false);
        setAppointmentModalOpen(false);
        setPartModalOpen(false);
        setConnectionModalOpen(false);
        setFocusedOrder(null);
      }
    };
    window.addEventListener("keydown", onShortcut as unknown as EventListener);
    return () => window.removeEventListener("keydown", onShortcut as unknown as EventListener);
  }, []);

  useEffect(() => {
    if (!initialData.conversations.length) return;
    if (selectedConversationId === null || !initialData.conversations.some((conversation) => conversation.id === selectedConversationId)) {
      setSelectedConversationId(initialData.conversations[0].id);
    }
  }, [initialData.conversations, selectedConversationId]);

  useEffect(() => {
    if (view !== "inbox") return;
    let mounted = true;
    const refresh = async () => {
      try {
        const [inboxResponse, statusResponse] = await Promise.all([
          fetch("/api/inbox", { cache: "no-store" }),
          fetch("/api/whatsapp", { cache: "no-store" }),
        ]);
        if (inboxResponse.ok) {
          const payload = await inboxResponse.json() as { conversations: ConversationRecord[] };
          if (mounted) setData((current) => ({ ...current, conversations: payload.conversations }));
        }
        if (statusResponse.ok) {
          const status = await statusResponse.json() as WhatsAppSnapshot;
          if (mounted) setWhatsAppStatus(status);
        }
      } catch {
        // La bandeja conserva los mensajes ya cargados si se pierde la conexión.
      }
    };
    void refresh();
    const timer = window.setInterval(refresh, 6500);
    return () => { mounted = false; window.clearInterval(timer); };
  }, [view]);

  useEffect(() => {
    if (!connectionModalOpen) return;
    let mounted = true;
    const refresh = async () => {
      try {
        const response = await fetch("/api/whatsapp", { cache: "no-store" });
        if (response.ok && mounted) setWhatsAppStatus(await response.json() as WhatsAppSnapshot);
      } catch {
        // Se puede reintentar desde el panel de conexión.
      }
    };
    void refresh();
    const timer = window.setInterval(refresh, 2200);
    return () => { mounted = false; window.clearInterval(timer); };
  }, [connectionModalOpen]);

  useEffect(() => {
    if (view !== "settings") return;
    let mounted = true;
    void fetch("/api/automations", { cache: "no-store" })
      .then(async (response) => {
        if (!response.ok) return;
        const payload = await response.json() as { automations: { key: string; title: string; description: string; active: boolean }[] };
        if (mounted && payload.automations.length) {
          setAutomationSettings(payload.automations.map((rule) => ({ id: rule.key, title: rule.title, description: rule.description, active: rule.active })));
        }
      })
      .catch(() => undefined);
    return () => { mounted = false; };
  }, [view]);

  const activeConversation = data.conversations.find((conversation) => conversation.id === selectedConversationId) ?? null;
  const unreadTotal = data.conversations.reduce((total, conversation) => total + conversation.unreadCount, 0);
  const lowStockCount = data.parts.filter((part) => part.stock <= part.minimumStock).length;
  const activeOrderCount = data.workOrders.filter((order) => order.status !== "entregado").length;
  const todayKey = caracasDateKey(new Date());
  const appointmentsToday = data.appointments.filter((appointment) => caracasDateKey(new Date(appointment.startsAt)) === todayKey).sort((a, b) => a.startsAt.localeCompare(b.startsAt));

  const filteredOrders = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("es-VE");
    return data.workOrders.filter((order) => {
      const matchesQuery = !query || [order.code, order.clientName, order.phone, order.vehicle, order.plate, order.service, order.technician].some((value) => value.toLocaleLowerCase("es-VE").includes(query));
      const matchesFilter = orderFilter === "all" || (orderFilter === "mine" ? order.technician.toLocaleLowerCase().includes("valentina") : order.priority === "alta");
      return matchesQuery && matchesFilter;
    });
  }, [data.workOrders, orderFilter, search]);

  const filteredCustomers = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("es-VE");
    return data.customers.filter((customer) => !query || [customer.name, customer.phone, customer.email, ...customer.vehicles.map((vehicle) => `${vehicle.make} ${vehicle.model} ${vehicle.plate}`)].some((value) => value.toLocaleLowerCase("es-VE").includes(query)));
  }, [data.customers, search]);

  const filteredVehicles = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("es-VE");
    return data.vehicles.filter((vehicle) => !query || [vehicle.make, vehicle.model, vehicle.plate, vehicle.customerName, vehicle.phone].some((value) => value.toLocaleLowerCase("es-VE").includes(query)));
  }, [data.vehicles, search]);

  const filteredParts = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("es-VE");
    return data.parts.filter((part) => !query || [part.sku, part.name, part.brand, part.category, part.supplier].some((value) => value.toLocaleLowerCase("es-VE").includes(query)));
  }, [data.parts, search]);

  const filteredConversations = useMemo(() => {
    const query = inboxSearch.trim().toLocaleLowerCase("es-VE");
    return data.conversations.filter((conversation) => {
      const matchQuery = !query || [conversation.customerName, conversation.phone, conversation.messages.at(-1)?.body ?? ""].some((value) => value.toLocaleLowerCase("es-VE").includes(query));
      const matchFilter = inboxFilter === "all" || (inboxFilter === "unread" ? conversation.unreadCount > 0 : conversation.assignee.toLocaleLowerCase().includes("valentina"));
      return matchQuery && matchFilter;
    });
  }, [data.conversations, inboxFilter, inboxSearch]);

  function goTo(nextView: ViewKey) {
    setView(nextView);
    setMobileSidebarOpen(false);
    setSearch("");
  }

  function changeOrderStatus(orderId: number, status: WorkOrderStatus) {
    const oldOrder = data.workOrders.find((order) => order.id === orderId);
    if (!oldOrder || oldOrder.status === status) return;
    setData((current) => ({
      ...current,
      workOrders: current.workOrders.map((order) => order.id === orderId ? { ...order, status, updatedAt: new Date().toISOString() } : order),
    }));
    void fetch("/api/work-orders", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: orderId, status }) })
      .then(async (response) => {
        if (!response.ok) throw new Error("No se guardó el cambio de etapa.");
        notify(`Orden ${oldOrder.code} movida a ${statusMeta(status).label.toLocaleLowerCase("es-VE")}.`);
      })
      .catch((error: Error) => {
        setData((current) => ({ ...current, workOrders: current.workOrders.map((order) => order.id === orderId ? { ...order, status: oldOrder.status } : order) }));
        notify(error.message || "No se pudo actualizar la orden.", "error");
      });
  }

  async function submitWorkOrder(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    try {
      const response = await fetch("/api/work-orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...orderDraft, year: orderDraft.year ? Number(orderDraft.year) : null, amount: Number(orderDraft.amount || 0) }),
      });
      const payload = await response.json() as { workOrder?: WorkOrderRecord; error?: string };
      if (!response.ok || !payload.workOrder) throw new Error(payload.error || "No se pudo crear la orden.");
      const order = payload.workOrder;
      setData((current) => {
        const customerExists = current.customers.some((customer) => customer.id === order.customerId);
        const vehicleExists = current.vehicles.some((vehicle) => vehicle.id === order.vehicleId);
        const nextCustomers = customerExists ? current.customers : [...current.customers, {
          id: order.customerId,
          name: order.clientName,
          phone: order.phone,
          email: orderDraft.email,
          notes: "",
          vehicles: order.vehicleId ? [{ id: order.vehicleId, make: orderDraft.make, model: orderDraft.model, year: orderDraft.year ? Number(orderDraft.year) : null, plate: order.plate }] : [],
          lastInteraction: order.updatedAt,
        }];
        const nextVehicles = vehicleExists || !order.vehicleId ? current.vehicles : [...current.vehicles, {
          id: order.vehicleId,
          customerId: order.customerId,
          customerName: order.clientName,
          phone: order.phone,
          make: orderDraft.make,
          model: orderDraft.model,
          year: orderDraft.year ? Number(orderDraft.year) : null,
          plate: order.plate,
          color: "",
        }];
        return { ...current, customers: nextCustomers, vehicles: nextVehicles, workOrders: [order, ...current.workOrders] };
      });
      setOrderModalOpen(false);
      setOrderDraft({ name: "", phone: "", email: "", make: "", model: "", year: "", plate: "", service: "", description: "", priority: "normal", status: "por_cotizar", amount: "" });
      notify(`Orden ${order.code} creada correctamente.`);
    } catch (error) {
      notify(error instanceof Error ? error.message : "No se pudo crear la orden.", "error");
    } finally {
      setBusy(false);
    }
  }

  async function submitClient(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    try {
      const response = await fetch("/api/clients", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(clientDraft) });
      const payload = await response.json() as { customer?: CustomerRecord; error?: string };
      if (!response.ok || !payload.customer) throw new Error(payload.error || "No se pudo guardar el cliente.");
      setData((current) => ({ ...current, customers: [payload.customer!, ...current.customers] }));
      setClientModalOpen(false);
      setClientDraft({ name: "", phone: "", email: "", notes: "" });
      notify("Cliente agregado al CRM.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "No se pudo guardar el cliente.", "error");
    } finally {
      setBusy(false);
    }
  }

  async function submitAppointment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    try {
      const booking = {
        ...appointmentDraft,
        startsAt: caracasIso(appointmentDraft.startsAt),
        year: appointmentDraft.year ? Number(appointmentDraft.year) : null,
      };
      const response = await fetch(appointmentSource === "assistant" ? "/api/assistant" : "/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(appointmentSource === "assistant" ? { booking } : booking),
      });
      const payload = await response.json() as { appointment?: AppointmentRecord; reply?: string; error?: string; appointmentId?: number };
      if (!response.ok) throw new Error(payload.error || "No se pudo agendar la cita.");
      if (appointmentSource === "assistant") {
        const refreshed = await fetch("/api/appointments", { cache: "no-store" });
        if (refreshed.ok) {
          const body = await refreshed.json() as { appointments: AppointmentRecord[] };
          setData((current) => ({ ...current, appointments: body.appointments }));
        }
        setAssistantMessages((current) => [
          ...current,
          { role: "assistant", body: payload.reply || "La cita quedó registrada.", at: new Date().toISOString() },
        ]);
        notify("Cita registrada desde el asistente.");
      } else if (payload.appointment) {
        setData((current) => ({ ...current, appointments: [...current.appointments, payload.appointment!] }));
        notify("Cita agregada al calendario.");
      }
      setAppointmentModalOpen(false);
      setAppointmentDraft({ name: "", phone: "", email: "", make: "", model: "", year: "", plate: "", service: services[0], startsAt: caracasInputValue(), notes: "" });
    } catch (error) {
      notify(error instanceof Error ? error.message : "No se pudo agendar la cita.", "error");
    } finally {
      setBusy(false);
    }
  }

  async function submitPart(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    try {
      const response = await fetch("/api/parts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...partDraft, stock: Number(partDraft.stock), minimumStock: Number(partDraft.minimumStock), price: Number(partDraft.price) }) });
      const payload = await response.json() as { part?: PartRecord; error?: string };
      if (!response.ok || !payload.part) throw new Error(payload.error || "No se pudo agregar el repuesto.");
      setData((current) => ({ ...current, parts: [payload.part!, ...current.parts] }));
      setPartModalOpen(false);
      setPartDraft({ sku: "", name: "", brand: "ACDelco", category: "Lubricantes", stock: "0", minimumStock: "3", price: "", supplier: "" });
      notify("Repuesto agregado al inventario.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "No se pudo agregar el repuesto.", "error");
    } finally {
      setBusy(false);
    }
  }

  async function adjustStock(part: PartRecord, change: number) {
    const nextStock = Math.max(0, part.stock + change);
    setData((current) => ({ ...current, parts: current.parts.map((item) => item.id === part.id ? { ...item, stock: nextStock } : item) }));
    try {
      const response = await fetch("/api/parts", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: part.id, stock: nextStock }) });
      if (!response.ok) throw new Error("No se guardó el nuevo stock.");
      notify(`Stock actualizado: ${part.name}.`);
    } catch (error) {
      setData((current) => ({ ...current, parts: current.parts.map((item) => item.id === part.id ? { ...item, stock: part.stock } : item) }));
      notify(error instanceof Error ? error.message : "No se pudo actualizar el stock.", "error");
    }
  }

  async function sendInboxMessage(event?: FormEvent<HTMLFormElement>) {
    event?.preventDefault();
    const text = inboxDraft.trim();
    if (!text || !activeConversation || busy) return;
    setBusy(true);
    try {
      const response = await fetch("/api/inbox", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ conversationId: activeConversation.id, body: text, author: "Valentina R." }) });
      const payload = await response.json() as { message?: MessageRecord; error?: string };
      if (!response.ok || !payload.message) throw new Error(payload.error || "No se pudo enviar el mensaje.");
      setData((current) => ({ ...current, conversations: current.conversations.map((conversation) => conversation.id === activeConversation.id ? { ...conversation, unreadCount: 0, status: "open", lastMessageAt: payload.message!.sentAt, messages: [...conversation.messages, payload.message!] } : conversation) }));
      setInboxDraft("");
      if (payload.message.deliveryStatus === "queued") notify("Mensaje guardado. Se enviará al conectar WhatsApp.");
      else notify("Mensaje enviado por WhatsApp.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "No se pudo enviar el mensaje.", "error");
    } finally {
      setBusy(false);
    }
  }

  async function suggestInboxReply() {
    if (!activeConversation) return;
    const latestIncoming = [...activeConversation.messages].reverse().find((message) => message.direction === "incoming");
    if (!latestIncoming) {
      notify("No hay mensajes entrantes para sugerir una respuesta.", "error");
      return;
    }
    try {
      const response = await fetch("/api/assistant", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: latestIncoming.body, customerName: activeConversation.customerName }) });
      const payload = await response.json() as { reply?: string; error?: string };
      if (!response.ok || !payload.reply) throw new Error(payload.error || "No se pudo generar una sugerencia.");
      setInboxDraft(payload.reply);
      inboxDraftRef.current?.focus();
    } catch (error) {
      notify(error instanceof Error ? error.message : "No se pudo generar una respuesta.", "error");
    }
  }

  async function updateAssignee(conversation: ConversationRecord) {
    const agents = ["Valentina R.", "José A.", "Marcos R.", "Sin asignar"];
    const currentIndex = agents.indexOf(conversation.assignee);
    const assignee = agents[(currentIndex + 1) % agents.length];
    setData((current) => ({ ...current, conversations: current.conversations.map((item) => item.id === conversation.id ? { ...item, assignee } : item) }));
    try {
      const response = await fetch("/api/inbox", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: conversation.id, action: "assign", assignee }) });
      if (!response.ok) throw new Error("No se pudo guardar la asignación.");
      notify(`Conversación asignada a ${assignee}.`);
    } catch {
      setData((current) => ({ ...current, conversations: current.conversations.map((item) => item.id === conversation.id ? { ...item, assignee: conversation.assignee } : item) }));
      notify("No se pudo actualizar el asesor asignado.", "error");
    }
  }

  async function toggleConversationResolution(conversation: ConversationRecord) {
    const action = conversation.status === "resolved" ? "reopen" : "resolve";
    const status = action === "resolve" ? "resolved" : "open";
    setData((current) => ({ ...current, conversations: current.conversations.map((item) => item.id === conversation.id ? { ...item, status } : item) }));
    try {
      const response = await fetch("/api/inbox", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: conversation.id, action }) });
      if (!response.ok) throw new Error("No se pudo guardar el estado.");
      notify(action === "resolve" ? "Conversación marcada como resuelta." : "Conversación reabierta.");
    } catch {
      setData((current) => ({ ...current, conversations: current.conversations.map((item) => item.id === conversation.id ? { ...item, status: conversation.status } : item) }));
      notify("No se pudo actualizar el estado de la conversación.", "error");
    }
  }

  async function sendAssistantMessage(event?: FormEvent<HTMLFormElement>, forcedText?: string) {
    event?.preventDefault();
    const text = (forcedText ?? assistantDraft).trim();
    if (!text || assistantBusy) return;
    setAssistantMessages((current) => [...current, { role: "user", body: text, at: new Date().toISOString() }]);
    setAssistantDraft("");
    setAssistantBusy(true);
    try {
      const response = await fetch("/api/assistant", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: text }) });
      const payload = await response.json() as { reply?: string; error?: string };
      if (!response.ok || !payload.reply) throw new Error(payload.error || "El asistente no pudo responder.");
      setAssistantMessages((current) => [...current, { role: "assistant", body: payload.reply!, at: new Date().toISOString() }]);
    } catch (error) {
      setAssistantMessages((current) => [...current, { role: "assistant", body: error instanceof Error ? error.message : "No pude conectarme ahora. Intenta de nuevo en un momento.", at: new Date().toISOString() }]);
    } finally {
      setAssistantBusy(false);
    }
  }

  async function connectWhatsApp() {
    setConnectionModalOpen(true);
    if (whatsAppStatus.status === "connected" || whatsAppStatus.status === "qr" || whatsAppStatus.status === "connecting") return;
    setWhatsAppStatus((current) => ({ ...current, status: "connecting" }));
    try {
      const response = await fetch("/api/whatsapp", { method: "POST" });
      const payload = await response.json() as WhatsAppSnapshot & { error?: string };
      if (!response.ok) throw new Error(payload.error || "No se pudo iniciar la conexión.");
      setWhatsAppStatus(payload);
    } catch (error) {
      setWhatsAppStatus({ status: "disconnected", qrDataUrl: null, phoneNumber: null, connected: false });
      notify(error instanceof Error ? error.message : "No se pudo iniciar WhatsApp.", "error");
    }
  }

  async function disconnectWhatsApp() {
    try {
      await fetch("/api/whatsapp", { method: "DELETE" });
      setWhatsAppStatus({ status: "disconnected", qrDataUrl: null, phoneNumber: null, connected: false });
      notify("Sesión de WhatsApp desconectada.");
    } catch {
      notify("No se pudo cerrar la sesión de WhatsApp.", "error");
    }
  }

  function openAppointment(source: "calendar" | "assistant") {
    setAppointmentSource(source);
    setAppointmentModalOpen(true);
    setAppointmentDraft((current) => ({ ...current, startsAt: caracasInputValue() }));
  }

  function toggleTask(id: number) {
    setTaskDone((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  }

  async function toggleAutomation(id: string) {
    const current = automationSettings.find((automation) => automation.id === id);
    if (!current) return;
    const next = !current.active;
    setAutomationSettings((settings) => settings.map((automation) => automation.id === id ? { ...automation, active: next } : automation));
    try {
      const response = await fetch("/api/automations", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ key: id, active: next }) });
      if (!response.ok) throw new Error("La configuración no se pudo guardar.");
      notify(next ? "Automatización activada." : "Automatización pausada.");
    } catch {
      setAutomationSettings((settings) => settings.map((item) => item.id === id ? { ...item, active: current.active } : item));
      notify("No se pudo guardar la automatización. Intenta nuevamente.", "error");
    }
  }

  const dateLabel = new Intl.DateTimeFormat("es-VE", { timeZone: TIME_ZONE, weekday: "long", day: "numeric", month: "long" }).format(new Date());
  const activeViewTitle = {
    dashboard: "Dashboard", tasks: "Tareas pendientes", calendar: "Calendario de citas", clients: "Clientes", vehicles: "Vehículos", orders: "Órdenes de trabajo", inventory: "Inventario", inbox: "Bandeja WhatsApp", assistant: "Asistente IA", templates: "Plantillas", settings: "Configuración",
  }[view];

  function renderOrders() {
    const columnCounts = statusColumns.map((column) => ({ ...column, count: filteredOrders.filter((order) => order.status === column.id).length }));
    return (
      <div className="workspace orders-workspace">
        <PageHeading eyebrow="Operaciones · Taller" title="Órdenes de trabajo" description={`${activeOrderCount} órdenes activas · Mantén cada servicio en movimiento.`} action={<><button className="secondary-button" type="button" onClick={() => notify("Vista exportada en formato CSV.")}><Download size={14} />Exportar</button><button className="primary-button" type="button" onClick={() => setOrderModalOpen(true)}><Plus size={15} />Nueva orden</button></>} />
        <div className="metric-grid">
          <MetricCard icon={Wrench} tone="green" label="En taller" value={data.workOrders.filter((order) => ["diagnostico", "esperando_repuesto"].includes(order.status)).length} note="Diagnóstico y servicio" trend="12%" />
          <MetricCard icon={CalendarCheck} tone="blue" label="Citas de hoy" value={appointmentsToday.length} note="En Maripérez" />
          <MetricCard icon={ClipboardList} tone="amber" label="Por cotizar" value={data.workOrders.filter((order) => order.status === "por_cotizar").length} note="Requieren seguimiento" />
          <MetricCard icon={Package} tone="violet" label="Stock bajo" value={lowStockCount} note="Revisar reposición" />
        </div>
        <section className="board-panel">
          <div className="board-topline">
            <div className="board-tabs">
              <button className={`board-tab${orderFilter === "all" ? " active" : ""}`} onClick={() => setOrderFilter("all")} type="button">Todas <span className="tab-count">{data.workOrders.length}</span></button>
              <button className={`board-tab${orderFilter === "mine" ? " active" : ""}`} onClick={() => setOrderFilter("mine")} type="button">Mis órdenes <span className="tab-count">{data.workOrders.filter((order) => order.technician.toLocaleLowerCase().includes("valentina")).length}</span></button>
              <button className={`board-tab${orderFilter === "priority" ? " active" : ""}`} onClick={() => setOrderFilter("priority")} type="button">Prioridad alta</button>
            </div>
            <div className="board-tools">
              <div className="filter-control">
                <button className="filter-button" type="button" onClick={() => setFilterOpen((open) => !open)}><Filter size={12} />{orderFilter === "priority" ? "Prioridad" : "Filtrar"}<ChevronDown size={11} /></button>
                {filterOpen ? <div className="filter-popover">{[{ key: "all", label: "Todas las órdenes" }, { key: "mine", label: "Asignadas a mí" }, { key: "priority", label: "Prioridad alta" }].map((option) => <button key={option.key} type="button" className={`filter-option${orderFilter === option.key ? " selected" : ""}`} onClick={() => { setOrderFilter(option.key as typeof orderFilter); setFilterOpen(false); }}>{option.label}{orderFilter === option.key ? <Check size={13} /> : null}</button>)}</div> : null}
              </div>
              <div className="view-toggle"><button type="button" className={orderMode === "kanban" ? "active" : ""} onClick={() => setOrderMode("kanban")}><LayoutDashboard size={12} />Kanban</button><button type="button" className={orderMode === "list" ? "active" : ""} onClick={() => setOrderMode("list")}><List size={12} />Lista</button></div>
            </div>
          </div>
          <div className="board-summary"><strong>{filteredOrders.length} órdenes</strong><span className="summary-dot" />Última actividad {formatRelative(data.workOrders[0]?.updatedAt || new Date().toISOString())}<span className="summary-dot" />Arrastra una tarjeta para cambiar de etapa</div>
          {orderMode === "kanban" ? (
            <div className="kanban-scroll">
              {columnCounts.map((column) => (
                <section className="kanban-column" key={column.id} onDragOver={(event) => event.preventDefault()} onDrop={(event) => { event.preventDefault(); if (draggingOrderId !== null) changeOrderStatus(draggingOrderId, column.id); setDraggingOrderId(null); }}>
                  <div className="column-heading"><i className="column-dot" style={{ background: column.dot }} /><strong>{column.label}</strong><span className="column-count">{column.count}</span><button className="column-add" type="button" aria-label={`Nueva orden ${column.label}`} onClick={() => { setOrderDraft((draft) => ({ ...draft, service: "", description: "" })); setOrderModalOpen(true); }}><Plus size={15} /></button></div>
                  {filteredOrders.filter((order) => order.status === column.id).length ? filteredOrders.filter((order) => order.status === column.id).map((order) => (
                    <div key={order.id} className={draggingOrderId === order.id ? "kanban-card dragging" : ""}>
                      <WorkOrderCard order={order} onMove={changeOrderStatus} onOpen={setFocusedOrder} onDragStart={setDraggingOrderId} />
                    </div>
                  )) : <div className="column-empty">{search ? "Sin coincidencias en esta etapa" : "No hay órdenes aquí todavía"}</div>}
                </section>
              ))}
            </div>
          ) : (
            <div className="data-table-wrap">
              <table className="data-table"><thead><tr><th>Orden / Cliente</th><th>Vehículo</th><th>Servicio</th><th>Estado</th><th>Técnico</th><th>Monto</th></tr></thead><tbody>{filteredOrders.map((order) => <tr key={order.id} onClick={() => setFocusedOrder(order)} style={{ cursor: "pointer" }}><td><div className="table-person"><Avatar name={order.clientName} small /><div><strong>{order.code} · {order.clientName}</strong><span>{order.phone}</span></div></div></td><td>{order.vehicle} · {order.plate}</td><td>{order.service}</td><td><StatusBadge status={order.status} /></td><td>{order.technician}</td><td>{order.amount ? formatMoney(order.amount) : "Por cotizar"}</td></tr>)}</tbody></table>
            </div>
          )}
          <div className="board-footer"><span>Mostrando {filteredOrders.length} de {data.workOrders.length} órdenes</span><button type="button" onClick={() => notify("Estás viendo todas las órdenes del taller.")}>Ver actividad del taller <ArrowRight size={12} /></button></div>
        </section>
      </div>
    );
  }

  function renderDashboard() {
    const pipeline = statusColumns.slice(0, 5).map((column) => ({ label: column.label, count: data.workOrders.filter((order) => order.status === column.id).length, color: column.dot }));
    const maxPipeline = Math.max(1, ...pipeline.map((item) => item.count));
    const chartValues = [3, 5, 4, 7, 5, 8, 6];
    const chartTargets = [2, 3, 4, 3, 6, 5, 4];
    const todayActivity = data.workOrders.slice(0, 4);
    return (
      <div className="workspace">
        <div className="dashboard-greeting"><div><div className="eyebrow"><i className="eyebrow-dot" />{formatCaracasDate(new Date(), { weekday: "long" })} · Maripérez, Caracas</div><h1>Buenos días, Valentina <span aria-hidden="true">✦</span></h1><p>Este es el resumen de tu taller para hoy, {formatCaracasDate(new Date(), { day: "numeric", month: "long" })}.</p></div><button className="primary-button" type="button" onClick={() => setOrderModalOpen(true)}><Plus size={15} />Nueva orden</button></div>
        <div className="metric-grid" style={{ margin: "0 0 15px" }}>
          <MetricCard icon={Wrench} tone="green" label="Órdenes activas" value={activeOrderCount} note="En todas las etapas" trend="8%" />
          <MetricCard icon={CalendarCheck} tone="blue" label="Citas para hoy" value={appointmentsToday.length} note={`Próxima a las ${formatCaracasTime(appointmentsToday[0]?.startsAt || new Date())}`} />
          <MetricCard icon={Users} tone="violet" label="Clientes registrados" value={data.customers.length} note="CRM de Tecnoclinic" />
          <MetricCard icon={AlertTriangle} tone="amber" label="Repuestos por reponer" value={lowStockCount} note="Stock en nivel mínimo" />
        </div>
        <div className="dashboard-grid">
          <div className="dashboard-main-column">
            <section className="panel-card"><div className="panel-header"><div><h2>Actividad del taller</h2><p>Órdenes creadas y servicios completados · últimos 7 días</p></div><button className="filter-button" type="button" onClick={() => notify("Mostrando actividad de los últimos 7 días.")}><CalendarDays size={12} />Esta semana<ChevronDown size={11} /></button></div><div className="activity-chart"><div className="chart-legend"><span><i />Órdenes creadas</span><span><i className="pale" />Completadas</span></div><div className="chart-bars">{chartValues.map((value, index) => <div className="chart-day" key={index}><div className="chart-bar" style={{ height: `${value * 10 + 9}%` }} /><div className="chart-bar main" style={{ height: `${chartTargets[index] * 10 + 9}%` }} /></div>)}</div><div className="chart-axis">{["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"].map((day) => <span key={day}>{day}</span>)}</div></div></section>
            <section className="panel-card"><div className="panel-header"><div><h2>Citas de hoy</h2><p>{formatCaracasDate(new Date(), { weekday: "long", day: "numeric", month: "long" })}</p></div><button type="button" className="panel-link" onClick={() => goTo("calendar")}>Ver calendario <ArrowRight size={12} /></button></div><div className="upcoming-list">{appointmentsToday.length ? appointmentsToday.slice(0, 4).map((appointment) => <div className="upcoming-item" key={appointment.id}><span className="appointment-time">{formatCaracasTime(appointment.startsAt)}</span><div className="appointment-info"><strong>{appointment.customerName} · {appointment.service}</strong><span>{appointment.vehicle} · {appointment.plate}</span></div><span className="appointment-type-icon"><CarFront size={14} /></span></div>) : <div className="column-empty">No hay citas programadas para hoy.<br />Agrega una visita al calendario.</div>}</div></section>
          </div>
          <div className="dashboard-side-column">
            <section className="panel-card"><div className="panel-header"><div><h2>Accesos rápidos</h2><p>Lo que necesitas, a un clic</p></div></div><div className="quick-action-grid"><button className="quick-action" type="button" onClick={() => setClientModalOpen(true)}><span className="quick-action-icon"><UserPlus size={14} /></span><span>Nuevo cliente</span></button><button className="quick-action" type="button" onClick={() => openAppointment("calendar")}><span className="quick-action-icon"><CalendarPlus size={14} /></span><span>Agendar cita</span></button><button className="quick-action" type="button" onClick={() => goTo("inbox")}><span className="quick-action-icon"><MessageCircle size={14} /></span><span>Abrir WhatsApp</span></button><button className="quick-action" type="button" onClick={() => goTo("inventory")}><span className="quick-action-icon"><Package size={14} /></span><span>Ver inventario</span></button></div></section>
            <section className="panel-card"><div className="panel-header"><div><h2>Órdenes por etapa</h2><p>Flujo de trabajo actual</p></div><button className="panel-link" type="button" onClick={() => goTo("orders")}>Ver tablero <ArrowRight size={12} /></button></div><div className="pipeline-list">{pipeline.map((item) => <div className="pipeline-row" key={item.label}><span>{item.label}</span><div className="pipeline-track"><div className="pipeline-fill" style={{ width: `${Math.max(8, item.count / maxPipeline * 100)}%`, background: item.color }} /></div><strong>{item.count}</strong></div>)}</div></section>
            <section className="panel-card"><div className="panel-header"><div><h2>Actividad reciente</h2><p>Últimos movimientos del taller</p></div></div><div className="activity-feed">{todayActivity.map((order) => <div className="activity-entry" key={order.id}><span className="activity-dot"><Wrench size={12} /></span><div><p><strong>{order.clientName}</strong> · {order.service}</p><small>{order.code} · {formatRelative(order.updatedAt)}</small></div></div>)}</div></section>
          </div>
        </div>
      </div>
    );
  }

  function renderTasks() {
    const openCount = tasks.length - taskDone.length;
    return <div className="workspace"><PageHeading eyebrow="Principal · Organización" title="Tareas pendientes" description={`${openCount} tareas por completar · Mantén al día el flujo del taller.`} action={<button className="primary-button" type="button" onClick={() => { const title = window.prompt("¿Qué tarea quieres agregar?"); if (title?.trim()) setTasks((current) => [{ id: Date.now(), title: title.trim(), detail: "Tarea creada por el equipo", due: "Hoy", kind: "General" }, ...current]); }}><Plus size={15} />Nueva tarea</button>} /><div className="panel-card"><div className="panel-header"><div><h2>Mi lista de trabajo</h2><p>Asesoría · Valentina Rojas</p></div><span className="status-pill s-blue">{openCount} pendientes</span></div><div className="task-list" style={{ padding: "0 16px 16px" }}>{tasks.map((task) => { const done = taskDone.includes(task.id); return <div className={`task-item${done ? " completed" : ""}`} key={task.id}><button type="button" className={`task-check${done ? " done" : ""}`} onClick={() => toggleTask(task.id)} aria-label={done ? "Marcar pendiente" : "Completar tarea"}>{done ? <Check size={12} /> : null}</button><div className="task-item-copy"><strong>{task.title}</strong><span>{task.detail}</span></div><span className="task-due"><Clock3 size={11} />{task.due}</span><span className="status-pill s-slate">{task.kind}</span></div>; })}</div></div></div>;
  }

  function renderCalendar() {
    const selectedDate = new Date(`${calendarDate}T12:00:00Z`);
    const weekday = selectedDate.getUTCDay();
    const monday = shiftDateKey(calendarDate, -((weekday + 6) % 7));
    const weekDays = Array.from({ length: 7 }, (_, index) => shiftDateKey(monday, index));
    const selectedAppointments = data.appointments.filter((appointment) => caracasDateKey(new Date(appointment.startsAt)) === calendarDate).sort((a, b) => a.startsAt.localeCompare(b.startsAt));
    const dateDisplay = new Intl.DateTimeFormat("es-VE", { timeZone: TIME_ZONE, month: "long", year: "numeric" }).format(new Date(`${calendarDate}T15:00:00Z`));
    const dayDisplay = new Intl.DateTimeFormat("es-VE", { timeZone: TIME_ZONE, weekday: "long", day: "numeric", month: "long" }).format(new Date(`${calendarDate}T15:00:00Z`));
    return <div className="workspace"><PageHeading eyebrow="Principal · Agenda" title="Calendario de citas" description="Coordina las visitas al taller y mantén a tus clientes informados." action={<button className="primary-button" type="button" onClick={() => openAppointment("calendar")}><CalendarPlus size={15} />Nueva cita</button>} /><div className="calendar-toolbar"><div className="calendar-range"><div className="calendar-arrows"><button type="button" aria-label="Semana anterior" onClick={() => setCalendarDate((date) => shiftDateKey(date, -7))}><ChevronLeft size={14} /></button><button type="button" aria-label="Semana siguiente" onClick={() => setCalendarDate((date) => shiftDateKey(date, 7))}><ChevronRight size={14} /></button></div><strong>{dateDisplay}</strong></div><button className="secondary-button" type="button" onClick={() => setCalendarDate(todayKey)}><CalendarDays size={13} />Hoy</button></div><div className="week-strip">{weekDays.map((key) => { const date = new Date(`${key}T15:00:00Z`); const dayName = new Intl.DateTimeFormat("es-VE", { timeZone: TIME_ZONE, weekday: "short" }).format(date).replace(".", ""); const dayNumber = new Intl.DateTimeFormat("es-VE", { timeZone: TIME_ZONE, day: "numeric" }).format(date); return <button type="button" className={`week-day${calendarDate === key ? " today" : ""}`} key={key} onClick={() => setCalendarDate(key)}><span>{dayName}</span><strong>{dayNumber}</strong></button>; })}</div><div className="calendar-columns"><section className="panel-card calendar-agenda"><div className="agenda-day-heading">{dayDisplay}</div>{selectedAppointments.length ? selectedAppointments.map((appointment) => <div className="agenda-entry" key={appointment.id}><span className="agenda-time">{formatCaracasTime(appointment.startsAt)}</span><span className="agenda-rail"><i /></span><div className="agenda-content"><strong>{appointment.customerName} · {appointment.service}</strong><span>{appointment.vehicle} · {appointment.plate} · {appointment.phone}</span></div><span className="agenda-assignee">{appointment.assignedTo}</span></div>) : <div className="column-empty" style={{ margin: "10px 16px 17px" }}>No hay citas para este día.<br />Puedes agendar una nueva visita.</div>}</section><aside className="panel-card calendar-info-card"><h3>Horario de atención</h3><div className="hours-row"><span>Lunes a viernes</span><strong>8:00 a. m. — 5:00 p. m.</strong></div><div className="hours-row"><span>Sábado</span><strong>8:00 a. m. — 1:00 p. m.</strong></div><div className="hours-row"><span>Domingo</span><strong>Cerrado</strong></div><div className="location-note"><MapPin size={13} /><span>Maripérez, Caracas<br />TecnoClinic Repuestos · J-311592024</span></div><div style={{ marginTop: 14 }}><button className="secondary-button" style={{ width: "100%" }} type="button" onClick={() => openAppointment("calendar")}><Plus size={13} />Agendar en esta fecha</button></div></aside></div></div>;
  }

  function renderClients() {
    return <div className="workspace"><PageHeading eyebrow="Operaciones · CRM" title="Clientes" description="Una ficha completa de cada cliente, su historial y sus vehículos." action={<button className="primary-button" type="button" onClick={() => setClientModalOpen(true)}><UserPlus size={15} />Nuevo cliente</button>} /><div className="crm-toolbar"><span className="view-count">{filteredCustomers.length} clientes registrados</span><button className="filter-button" type="button" onClick={() => notify("Mostrando todos los clientes activos.")}><SlidersHorizontal size={12} />Todos los clientes<ChevronDown size={11} /></button></div><div className="crm-grid">{filteredCustomers.map((customer) => <article className="crm-card" key={customer.id}><div className="crm-card-header"><Avatar name={customer.name} /><div className="crm-card-head-copy"><strong>{customer.name}</strong><span>Cliente desde {formatCaracasDate(customer.lastInteraction, { month: "short", year: "numeric" })}</span></div><button className="crm-card-menu" type="button" aria-label="Opciones de cliente" onClick={() => { navigator.clipboard?.writeText(customer.phone); notify("Teléfono copiado al portapapeles."); }}><MoreHorizontal size={15} /></button></div><div className="crm-card-meta"><div className="crm-meta-item"><span>Teléfono</span><strong>{customer.phone}</strong></div><div className="crm-meta-item"><span>Última interacción</span><strong>{formatRelative(customer.lastInteraction)}</strong></div></div><div className="crm-card-meta" style={{ marginTop: 9, paddingTop: 9 }}><div className="crm-meta-item"><span>Correo</span><strong>{customer.email || "Sin registrar"}</strong></div><div className="crm-meta-item"><span>Vehículos</span><strong>{customer.vehicles.length} registrado{customer.vehicles.length === 1 ? "" : "s"}</strong></div></div><div className="crm-card-vehicles"><CarFront size={12} />{customer.vehicles.length ? customer.vehicles.map((vehicle) => `${vehicle.make} ${vehicle.model} · ${vehicle.plate}`).join("  /  ") : "Aún no tiene vehículos registrados"}</div></article>)}{!filteredCustomers.length ? <div className="column-empty">No hay clientes que coincidan con la búsqueda.</div> : null}</div></div>;
  }

  function renderVehicles() {
    return <div className="workspace"><PageHeading eyebrow="Operaciones · CRM" title="Vehículos" description="Vehículos vinculados a los clientes y órdenes de servicio." action={<button className="primary-button" type="button" onClick={() => { setOrderModalOpen(true); notify("Completa los datos del cliente y vehículo para registrarlo con una orden."); }}><Plus size={15} />Registrar vehículo</button>} /><div className="crm-toolbar"><span className="view-count">{filteredVehicles.length} vehículos · {data.customers.length} propietarios</span><button className="filter-button" type="button" onClick={() => notify("Viendo todos los vehículos registrados.")}><Filter size={12} />Todos<ChevronDown size={11} /></button></div><div className="crm-grid">{filteredVehicles.map((vehicle) => <article className="vehicle-card" key={vehicle.id}><div className="vehicle-card-top"><span className="vehicle-brand-icon"><CarFront size={18} /></span><span className="vehicle-plate-large">{vehicle.plate}</span></div><h3>{vehicle.make} {vehicle.model} {vehicle.year ?? ""}</h3><p>{vehicle.color ? `${vehicle.color} · ` : ""}Registrado en TecnoClinic</p><div className="vehicle-owner"><Avatar name={vehicle.customerName} round small />{vehicle.customerName}<span style={{ marginLeft: "auto", color: "#9aa4b1" }}>{vehicle.phone}</span></div></article>)}{!filteredVehicles.length ? <div className="column-empty">No hay vehículos que coincidan con la búsqueda.</div> : null}</div></div>;
  }

  function renderInventory() {
    const totalStock = data.parts.reduce((total, part) => total + part.stock, 0);
    const lowStockParts = data.parts.filter((part) => part.stock <= part.minimumStock);
    return <div className="workspace"><PageHeading eyebrow="Operaciones · Repuestos" title="Inventario de repuestos" description="Controla existencias, consulta precios y prioriza la reposición de piezas." action={<button className="primary-button" type="button" onClick={() => setPartModalOpen(true)}><Plus size={15} />Agregar repuesto</button>} /><div className="inventory-summary"><MetricCard icon={Package} tone="green" label="Referencias activas" value={data.parts.length} note="En catálogo" /><MetricCard icon={Gauge} tone="blue" label="Unidades en stock" value={totalStock} note="Existencia total" /><MetricCard icon={AlertTriangle} tone="amber" label="Stock bajo" value={lowStockParts.length} note="Requiere reposición" /></div>{lowStockParts.length ? <div className="low-stock-banner"><AlertTriangle size={14} /><span><strong>{lowStockParts.length} referencias</strong> están en su nivel mínimo o por debajo. Revisa las existencias antes de cotizar.</span><button type="button" className="panel-link" onClick={() => notify(`Revisa: ${lowStockParts.map((part) => part.name).join(", ")}.`)}>Ver alertas <ArrowRight size={12} /></button></div> : null}<div className="inventory-table-card"><div className="data-table-wrap" style={{ margin: 0, border: 0, borderRadius: 0 }}><table className="data-table"><thead><tr><th>Repuesto</th><th>Categoría</th><th>Existencia</th><th>Precio ref.</th><th>Proveedor</th><th>Acciones</th></tr></thead><tbody>{filteredParts.map((part) => { const level = part.stock === 0 ? "out" : part.stock <= part.minimumStock ? "low" : ""; return <tr key={part.id}><td><div className="inventory-row-title"><span className="product-mark"><Package size={14} /></span><span className="product-copy"><strong>{part.name}</strong><span>{part.brand} · SKU {part.sku}</span></span></div></td><td><span className="status-pill s-slate">{part.category}</span></td><td><span className={`stock-count ${level}`}><i className="stock-indicator" />{part.stock} unidades {level ? (level === "out" ? "· agotado" : "· bajo") : ""}</span></td><td>{formatMoney(part.price)}</td><td>{part.supplier}</td><td><div style={{ display: "flex", gap: 5 }}><button type="button" className="table-action" onClick={() => adjustStock(part, -1)} aria-label={`Restar stock de ${part.name}`}>−</button><button type="button" className="table-action" onClick={() => adjustStock(part, 1)} aria-label={`Sumar stock de ${part.name}`}>+ Ajustar</button></div></td></tr>; })}</tbody></table>{!filteredParts.length ? <div className="column-empty" style={{ margin: 12 }}>No hay repuestos que coincidan con la búsqueda.</div> : null}</div></div></div>;
  }

  function renderInbox() {
    const showConnectionLabel = whatsAppStatus.connected ? "WhatsApp conectado" : "Conectar WhatsApp";
    const messagesForActive = activeConversation?.messages ?? [];
    return <div className="workspace"><PageHeading eyebrow="Comunicación · WhatsApp" title="Bandeja compartida" description="Conversaciones del equipo, centralizadas en un solo lugar." action={<><span className={`qr-status${whatsAppStatus.connected ? " connected" : ""}`}><i />{whatsAppStatus.connected ? `Conectado${whatsAppStatus.phoneNumber ? ` · +${whatsAppStatus.phoneNumber}` : ""}` : "Sesión desconectada"}</span><button className={whatsAppStatus.connected ? "secondary-button" : "primary-button"} type="button" onClick={whatsAppStatus.connected ? () => setConnectionModalOpen(true) : () => void connectWhatsApp()}>{whatsAppStatus.connected ? <Settings size={14} /> : <QrCode size={14} />}{showConnectionLabel}</button></>} /><div className="inbox-shell"><aside className="inbox-list-pane"><div className="inbox-list-header"><div className="inbox-list-title"><h2>Conversaciones</h2><span>{unreadTotal} sin leer</span></div><div className="inbox-filter-tabs"><button className={inboxFilter === "all" ? "active" : ""} type="button" onClick={() => setInboxFilter("all")}>Todas</button><button className={inboxFilter === "unread" ? "active" : ""} type="button" onClick={() => setInboxFilter("unread")}>Sin leer</button><button className={inboxFilter === "mine" ? "active" : ""} type="button" onClick={() => setInboxFilter("mine")}>Asignadas</button></div><div className="inbox-list-search"><Search size={12} /><input value={inboxSearch} onChange={(event) => setInboxSearch(event.target.value)} placeholder="Buscar conversación…" /></div></div><div className="conversation-list">{filteredConversations.map((conversation) => { const last = conversation.messages.at(-1); return <button type="button" key={conversation.id} className={`conversation-row${selectedConversationId === conversation.id ? " active" : ""}`} onClick={() => { setSelectedConversationId(conversation.id); setData((current) => ({ ...current, conversations: current.conversations.map((item) => item.id === conversation.id ? { ...item, unreadCount: 0 } : item) })); void fetch("/api/inbox", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: conversation.id, action: "read" }) }); }}><span className={`conversation-avatar ${avatarClass(conversation.customerName)}`}>{initials(conversation.customerName)}<i className="online-status" /></span><span className="conversation-main"><span className="conversation-line"><strong>{conversation.customerName}</strong><time>{formatRelative(conversation.lastMessageAt)}</time></span><span className="conversation-snippet">{last?.direction === "outgoing" ? "Tú: " : ""}{last?.body || "Sin mensajes"}</span><span className="conversation-bottom"><span className="conversation-agent"><MessageCircle size={10} />{conversation.assignee}</span>{conversation.unreadCount ? <span className="conversation-unread">{conversation.unreadCount}</span> : <span className="whatsapp-channel"><MessageCircle size={10} />WhatsApp</span>}</span></span></button>; })}{!filteredConversations.length ? <div className="inbox-empty"><div><MessageCircle size={23} /><br />No hay conversaciones que coincidan con tu búsqueda.</div></div> : null}</div></aside><section className="inbox-thread">{activeConversation ? <><header className="thread-header"><Avatar name={activeConversation.customerName} round /><div className="thread-header-copy"><strong>{activeConversation.customerName}</strong><span><i className="nav-status-dot" style={{ width: 6, height: 6, marginLeft: 0 }} />{activeConversation.phone || "Contacto de WhatsApp"} · WhatsApp</span></div><button className="thread-assignee" type="button" onClick={() => void updateAssignee(activeConversation)} title="Cambiar asesor asignado"><UserCog size={12} />{activeConversation.assignee}<ChevronDown size={11} /></button><div className="thread-header-actions"><button className="thread-action" type="button" aria-label="Llamar al cliente" onClick={() => activeConversation.phone ? window.open(`tel:${activeConversation.phone}`, "_self") : notify("Este contacto no tiene un teléfono registrado.", "error")}><Phone size={14} /></button><button className="thread-action" type="button" aria-label="Sugerir respuesta con IA" onClick={() => void suggestInboxReply()}><Sparkles size={14} /></button><button className="thread-action" type="button" aria-label={activeConversation.status === "resolved" ? "Reabrir conversación" : "Resolver conversación"} title={activeConversation.status === "resolved" ? "Reabrir conversación" : "Resolver conversación"} onClick={() => void toggleConversationResolution(activeConversation)}>{activeConversation.status === "resolved" ? <MessageCircle size={15} /> : <CheckCircle2 size={15} />}</button></div></header><div className="thread-message-area"><div className="message-day-separator">Hoy · America/Caracas</div>{messagesForActive.map((message) => <div className={`message-row${message.direction === "outgoing" ? " outgoing" : ""}`} key={message.id}>{message.direction !== "outgoing" ? <span className="message-sender-avatar">{initials(activeConversation.customerName)}</span> : null}<div className="message-bubble"><p>{message.body}</p><span className="message-meta">{message.direction === "outgoing" && message.author ? `${message.author} · ` : ""}{formatCaracasTime(message.sentAt)}{message.direction === "outgoing" ? <CheckCheck size={11} /> : null}</span></div></div>)}</div><div className="thread-ai-suggestion"><Sparkles size={13} /><span>Asistente IA listo para redactar una respuesta basada en esta conversación.</span><button type="button" onClick={() => void suggestInboxReply()}>Sugerir respuesta</button></div><form className="thread-composer" onSubmit={(event) => void sendInboxMessage(event)}><div className="composer-tools"><button type="button" title="Adjuntar archivo" onClick={() => notify("Adjuntar archivos estará disponible al conectar el almacenamiento.")}><Paperclip size={13} /></button><button type="button" title="Plantillas" onClick={() => goTo("templates")}><FileText size={13} /></button><button type="button" title="Insertar respuesta IA" onClick={() => void suggestInboxReply()}><Sparkles size={13} /></button><span style={{ marginLeft: "auto", color: "#a0a9b6", fontSize: 8 }}>Respuesta compartida · Valentina R.</span></div><div className="composer-textbox"><textarea ref={inboxDraftRef} value={inboxDraft} onChange={(event) => setInboxDraft(event.target.value)} placeholder="Escribe un mensaje…" rows={1} onKeyDown={(event: KeyboardEvent<HTMLTextAreaElement>) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void sendInboxMessage(); } }} /><button className="send-button" type="submit" disabled={!inboxDraft.trim() || busy} aria-label="Enviar mensaje">{busy ? <LoaderCircle size={14} className="animate-spin" /> : <Send size={14} />}</button></div><div className="composer-footnote"><span>Enter para enviar · Shift + Enter para salto de línea</span><span>{whatsAppStatus.connected ? "WhatsApp listo" : "Se guardará en cola hasta conectar WhatsApp"}</span></div></form></> : <div className="inbox-empty"><div><InboxIcon size={26} /><br />Selecciona una conversación para ver los mensajes.</div></div>}</section></div></div>;
  }

  function renderAssistant() {
    return <div className="workspace"><PageHeading eyebrow="Comunicación · Automatización" title="Asistente de IA" description="Un copiloto para responder consultas, sugerir repuestos y agendar citas." action={<button className="secondary-button" type="button" onClick={() => openAppointment("assistant")}><CalendarPlus size={14} />Agendar cita</button>} /><div className="assistant-layout"><section className="assistant-chat-card"><div className="assistant-hero"><span className="ai-orb"><Bot size={26} /></span><div className="assistant-hero-copy"><span>TecnoClinic · Asistente virtual</span><h2>Atención que siempre está lista</h2><p>Conoce el catálogo, los servicios del laboratorio y la agenda de Maripérez.</p></div><span className="ai-online-badge"><i />Activo</span></div><div className="assistant-chat-history">{assistantMessages.map((message, index) => <div className={`ai-message${message.role === "user" ? " user" : ""}`} key={`${index}-${message.at}`}>{message.role === "assistant" ? <span className="ai-message-icon"><Sparkles size={14} /></span> : null}<div className="ai-message-bubble"><small>{message.role === "assistant" ? "TecnoClinic IA" : "Tú"} · {formatCaracasTime(message.at)}</small>{message.body}</div></div>)}{assistantBusy ? <div className="ai-message"><span className="ai-message-icon"><Sparkles size={14} /></span><span className="typing-indicator"><i /><i /><i /></span></div> : null}</div><div className="assistant-suggestions"><button type="button" onClick={() => void sendAssistantMessage(undefined, "¿Tienen aceite ACDelco 5W-30 disponible y cuánto cuesta?")}><Package size={11} />Consultar un repuesto</button><button type="button" onClick={() => void sendAssistantMessage(undefined, "¿Qué servicios de limpieza de inyectores ofrecen?")}><Wrench size={11} />Servicios del taller</button><button type="button" onClick={() => openAppointment("assistant")}><CalendarPlus size={11} />Agendar una cita</button></div><div className="assistant-input-wrap"><form className="assistant-input" onSubmit={(event) => void sendAssistantMessage(event)}><textarea ref={assistantDraftRef} value={assistantDraft} onChange={(event) => setAssistantDraft(event.target.value)} placeholder="Prueba: ¿hay bujías NGK para mi vehículo?" rows={1} onKeyDown={(event: KeyboardEvent<HTMLTextAreaElement>) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void sendAssistantMessage(); } }} /><button className="ai-send" type="submit" disabled={!assistantDraft.trim() || assistantBusy} aria-label="Enviar consulta">{assistantBusy ? <LoaderCircle size={14} className="animate-spin" /> : <Send size={14} />}</button></form></div></section><aside className="ai-side-panel"><section className="ai-side-card"><h3><Sparkles size={14} />Qué puede hacer</h3><div className="ai-capability"><Package size={13} /><div><strong>Consultar repuestos</strong><span>Stock y precios de referencia del inventario real.</span></div></div><div className="ai-capability"><Wrench size={13} /><div><strong>Orientar sobre servicios</strong><span>Inyectores, escáner y mecánica rápida.</span></div></div><div className="ai-capability"><CalendarCheck size={13} /><div><strong>Registrar una cita</strong><span>Guarda la visita en el calendario del taller.</span></div></div><div className="ai-capability"><MessageCircle size={13} /><div><strong>Apoyar al equipo</strong><span>Redacta respuestas para la bandeja WhatsApp.</span></div></div></section><section className="ai-side-card"><h3><ShieldCheck size={14} />Conocimiento del taller</h3><div className="ai-capability"><MapPin size={13} /><div><strong>Maripérez, Caracas</strong><span>America/Caracas · RIF J-311592024</span></div></div><div className="ai-capability"><Clock3 size={13} /><div><strong>Lun–Vie 8–5 · Sáb 8–1</strong><span>Horario de referencia del taller.</span></div></div></section><div className="ai-connection-note"><strong>Router LLM:</strong> si hay una clave de OpenRouter u OpenAI configurada en el servidor, el asistente la utiliza. Sin clave, responde con el catálogo y flujos locales.</div></aside></div></div>;
  }

  function renderTemplates() {
    const templates = [
      { type: "Atención", title: "Saludo inicial", body: "¡Hola! 👋 Gracias por escribir a Tecnoclinic Repuestos. Cuéntanos qué necesita tu vehículo y con gusto te ayudamos. Estamos en Maripérez, Caracas." },
      { type: "Citas", title: "Confirmación de cita", body: "¡Tu cita en Tecnoclinic está confirmada! 🗓️ Te esperamos en Maripérez. Si necesitas cambiar el horario, responde a este mensaje." },
      { type: "Cotizaciones", title: "Cotización lista", body: "Hola, {{nombre}}. Ya tenemos lista la cotización para tu {{vehículo}}. ¿Te gustaría que reservemos los repuestos?" },
      { type: "Taller", title: "Vehículo listo", body: "¡Buenas noticias, {{nombre}}! Tu vehículo está listo para retirar. Te esperamos en Tecnoclinic Repuestos, Maripérez. 🚘" },
    ];
    return <div className="workspace"><PageHeading eyebrow="Comunicación · WhatsApp" title="Plantillas de mensajes" description="Respuestas rápidas para brindar una atención consistente y cercana." action={<button className="primary-button" type="button" onClick={() => { const title = window.prompt("Nombre de la plantilla"); if (title?.trim()) notify(`Plantilla “${title}” creada para editar.`); }}><Plus size={15} />Nueva plantilla</button>} /><div className="template-grid">{templates.map((template) => <article className="template-card" key={template.title}><div className="template-card-top"><span className="template-tag">{template.type}</span><button className="crm-card-menu" type="button" aria-label={`Opciones ${template.title}`} onClick={() => notify(`Plantilla “${template.title}” lista para editar.`)}><MoreHorizontal size={15} /></button></div><h3>{template.title}</h3><p>{template.body}</p><div className="template-card-footer"><span>WhatsApp · Español</span><button type="button" onClick={async () => { try { await navigator.clipboard.writeText(template.body); notify("Mensaje copiado al portapapeles."); } catch { notify(template.body, "success"); } }}><Copy size={11} />Copiar mensaje</button></div></article>)}</div></div>;
  }

  function renderSettings() {
    return <div className="workspace"><PageHeading eyebrow="Sistema · TecnoClinic Hub" title="Configuración" description="Información del negocio, equipo y automatizaciones de atención." action={<a href="/login" className="secondary-button" style={{ textDecoration: "none" }}><UserCog size={14} />Acceso del equipo</a>} /><div className="settings-layout"><div><section className="settings-card"><h2>Automatizaciones</h2><p>Elige qué tareas pueden ayudar a gestionar el flujo del taller.</p>{automationSettings.map((item) => <div className="settings-row" key={item.id}><div className="settings-row-copy"><strong>{item.title}</strong><span>{item.description}</span></div><button type="button" className={`toggle-switch${item.active ? " on" : ""}`} aria-label={`${item.active ? "Pausar" : "Activar"} ${item.title}`} onClick={() => void toggleAutomation(item.id)} /></div>)}</section><section className="settings-card"><h2>Integraciones</h2><p>Canales y servicios vinculados a TecnoClinic Hub.</p><div className="settings-row"><div className="settings-row-copy"><strong>WhatsApp · Bandeja compartida</strong><span>{whatsAppStatus.connected ? `Conectado${whatsAppStatus.phoneNumber ? ` · +${whatsAppStatus.phoneNumber}` : ""}` : "Escanea el QR para iniciar sesión en el dispositivo del taller."}</span></div><button className={whatsAppStatus.connected ? "secondary-button" : "primary-button"} style={{ minHeight: 30, padding: "0 9px", fontSize: 8.5 }} type="button" onClick={() => whatsAppStatus.connected ? setConnectionModalOpen(true) : void connectWhatsApp()}><QrCode size={12} />{whatsAppStatus.connected ? "Administrar" : "Conectar"}</button></div><div className="settings-row"><div className="settings-row-copy"><strong>LLM Router · Asistente</strong><span>OpenRouter / OpenAI-compatible vía variables de entorno del servidor.</span></div><span className="status-pill s-green"><i className="status-mini-dot" />Local + API</span></div><div className="settings-row"><div className="settings-row-copy"><strong>Zona horaria</strong><span>Agenda y mensajes del taller</span></div><strong style={{ color: "#4e5d71", fontSize: 9 }}>America/Caracas</strong></div></section><section className="settings-card"><h2>Equipo y permisos</h2><p>Roles disponibles para el acceso autenticado.</p><div className="settings-row"><div className="settings-row-copy"><strong>Administrador</strong><span>CRM, configuración, inventario y usuarios.</span></div><span className="status-pill s-purple">Admin</span></div><div className="settings-row"><div className="settings-row-copy"><strong>Técnico / Asesor</strong><span>Órdenes, clientes, citas y conversaciones.</span></div><span className="status-pill s-blue">Equipo</span></div></section></div><aside><section className="business-card"><div className="business-icon"><Activity size={17} /></div><h3>Tecnoclinic Repuestos</h3><p>Taller, laboratorio de inyectores y repuestos para mantener cada vehículo en marcha.</p><div className="business-detail"><MapPin size={12} />Maripérez, Caracas</div><div className="business-detail"><ShieldCheck size={12} />RIF J-311592024</div><div className="business-detail"><MessageCircle size={12} />@tecnoclinicrepuestos</div></section><section className="ai-side-card" style={{ marginTop: 12 }}><h3><DatabaseIcon />Datos y seguridad</h3><div className="ai-capability"><ShieldCheck size={13} /><div><strong>Contraseñas protegidas</strong><span>Hash bcrypt y sesión JWT de Auth.js.</span></div></div><div className="ai-capability"><Package size={13} /><div><strong>PostgreSQL + Drizzle</strong><span>Base de datos de operaciones y CRM.</span></div></div><div className="ai-capability"><QrCode size={13} /><div><strong>Sesión WhatsApp en disco</strong><span>Auth local persistente para Baileys.</span></div></div></section></aside></div></div>;
  }

  function DatabaseIcon() {
    return <Activity size={14} />;
  }

  return (
    <div className="app-shell">
      {mobileSidebarOpen ? <div className="mobile-sidebar-backdrop" onClick={() => setMobileSidebarOpen(false)} /> : null}
      <aside className={`sidebar${mobileSidebarOpen ? " mobile-open" : ""}`}>
        <div className="sidebar-top"><div className="brand-lockup"><div className="brand-mark"><Activity size={20} strokeWidth={2.4} /></div><div className="brand-copy"><strong>TECNOCLINIC</strong><small>HUB DE OPERACIONES</small></div></div><button type="button" className="branch-select" onClick={() => notify("Sede activa: Maripérez, Caracas.")}><span className="branch-icon"><MapPin size={15} /></span><span className="branch-copy"><strong>TecnoClinic · Maripérez</strong><span>Caracas, Venezuela</span></span><ChevronDown size={13} /></button></div>
        <nav className="nav-scroll" aria-label="Navegación principal">{navGroups.map((group) => <div className="nav-group" key={group.label}><div className="nav-label">{group.label}</div>{group.items.map((item) => { const Icon = item.icon; const badgeValue = item.badge === "tasks" ? tasks.length - taskDone.length : item.badge === "inbox" ? unreadTotal : item.badge === "stock" ? lowStockCount : null; return <button type="button" key={item.key} className={`nav-item${view === item.key ? " active" : ""}`} onClick={() => goTo(item.key)}><Icon size={15} strokeWidth={1.8} /><span>{item.label}</span>{item.badge === "ai" ? <i className="nav-status-dot" /> : badgeValue && badgeValue > 0 ? <span className={`nav-count${item.badge === "stock" ? " green" : ""}`}>{badgeValue}</span> : null}</button>; })}</div>)}</nav>
        <div className="sidebar-bottom"><button className="nav-item" type="button" onClick={() => notify("Centro de ayuda de TecnoClinic Hub.")}><CircleHelp size={15} /><span>Ayuda y soporte</span></button><button className={`nav-item${view === "settings" ? " active" : ""}`} type="button" onClick={() => goTo("settings")}><Settings size={15} /><span>Configuración</span></button><div className="user-profile"><span className="profile-avatar">VR</span><span className="profile-copy"><strong>Valentina Rojas</strong><span>Administradora</span></span><a className="profile-menu" href="/login" aria-label="Acceso del equipo"><ChevronDown size={13} /></a></div></div>
      </aside>
      <div className="main-shell">
        <header className="topbar"><button className="mobile-menu" type="button" onClick={() => setMobileSidebarOpen(true)} aria-label="Abrir menú"><Menu size={17} /></button><div className="global-search"><Search size={15} /><input ref={searchRef} value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Buscar clientes, vehículos, órdenes…" aria-label="Búsqueda global" /><span className="search-shortcut">⌘ K</span></div><span className="topbar-spacer" /><span className="topbar-date"><CalendarDays size={13} />{dateLabel}</span><span className="topbar-divider" /><button className="topbar-icon" type="button" aria-label="Notificaciones" onClick={() => notify(`${unreadTotal} mensajes sin leer · ${lowStockCount} alertas de inventario.`)}><Bell size={16} /><i className="notification-dot" /></button><button className="topbar-icon help-button" type="button" aria-label="Ayuda" onClick={() => goTo("settings")}><CircleHelp size={16} /></button><a href="/login" className="topbar-avatar" aria-label="Perfil del equipo">VR</a></header>
        <main className="workspace-scroll" key={view}>
          {view === "dashboard" ? renderDashboard() : null}
          {view === "tasks" ? renderTasks() : null}
          {view === "calendar" ? renderCalendar() : null}
          {view === "clients" ? renderClients() : null}
          {view === "vehicles" ? renderVehicles() : null}
          {view === "orders" ? renderOrders() : null}
          {view === "inventory" ? renderInventory() : null}
          {view === "inbox" ? renderInbox() : null}
          {view === "assistant" ? renderAssistant() : null}
          {view === "templates" ? renderTemplates() : null}
          {view === "settings" ? renderSettings() : null}
        </main>
      </div>

      {orderModalOpen ? <Modal title="Nueva orden de trabajo" description="Registra al cliente, el vehículo y el servicio solicitado." icon={Wrench} onClose={() => setOrderModalOpen(false)} wide><form onSubmit={(event) => void submitWorkOrder(event)}><div className="form-grid"><div className="form-field"><label>Nombre del cliente *</label><input required value={orderDraft.name} onChange={(event) => setOrderDraft((draft) => ({ ...draft, name: event.target.value }))} placeholder="Ej. Mariana González" /></div><div className="form-field"><label>Teléfono / WhatsApp *</label><input required value={orderDraft.phone} onChange={(event) => setOrderDraft((draft) => ({ ...draft, phone: event.target.value }))} placeholder="+58 412 000 0000" /></div><div className="form-field"><label>Correo <span>opcional</span></label><input type="email" value={orderDraft.email} onChange={(event) => setOrderDraft((draft) => ({ ...draft, email: event.target.value }))} placeholder="cliente@correo.com" /></div><div className="form-field"><label>Servicio solicitado *</label><select required value={orderDraft.service} onChange={(event) => setOrderDraft((draft) => ({ ...draft, service: event.target.value }))}><option value="">Selecciona un servicio</option>{services.map((service) => <option key={service} value={service}>{service}</option>)}</select></div><div className="form-field"><label>Marca del vehículo <span>opcional</span></label><input value={orderDraft.make} onChange={(event) => setOrderDraft((draft) => ({ ...draft, make: event.target.value }))} placeholder="Toyota" /></div><div className="form-field"><label>Modelo / año</label><div style={{ display: "flex", gap: 7 }}><input style={{ flex: 1 }} value={orderDraft.model} onChange={(event) => setOrderDraft((draft) => ({ ...draft, model: event.target.value }))} placeholder="Corolla" /><input style={{ width: 90 }} inputMode="numeric" value={orderDraft.year} onChange={(event) => setOrderDraft((draft) => ({ ...draft, year: event.target.value }))} placeholder="Año" /></div></div><div className="form-field"><label>Placa <span>opcional</span></label><input value={orderDraft.plate} onChange={(event) => setOrderDraft((draft) => ({ ...draft, plate: event.target.value.toUpperCase() }))} placeholder="ABC123" /></div><div className="form-field"><label>Etapa inicial</label><select value={orderDraft.status} onChange={(event) => setOrderDraft((draft) => ({ ...draft, status: event.target.value as WorkOrderStatus }))}><option value="por_cotizar">Por cotizar</option>{statusColumns.slice(1).map((column) => <option value={column.id} key={column.id}>{column.label}</option>)}</select></div><div className="form-field"><label>Prioridad</label><select value={orderDraft.priority} onChange={(event) => setOrderDraft((draft) => ({ ...draft, priority: event.target.value }))}><option value="normal">Normal</option><option value="alta">Alta</option></select></div><div className="form-field"><label>Monto estimado <span>USD · opcional</span></label><input type="number" min="0" step="0.01" value={orderDraft.amount} onChange={(event) => setOrderDraft((draft) => ({ ...draft, amount: event.target.value }))} placeholder="0.00" /></div><div className="form-field full"><label>Notas del servicio</label><textarea value={orderDraft.description} onChange={(event) => setOrderDraft((draft) => ({ ...draft, description: event.target.value }))} placeholder="Síntomas, repuestos a cotizar o notas para el técnico…" /></div></div><div className="modal-footer"><button className="secondary-button" type="button" onClick={() => setOrderModalOpen(false)}>Cancelar</button><button className="primary-button" type="submit" disabled={busy}>{busy ? <LoaderCircle size={14} className="animate-spin" /> : <Plus size={14} />}Crear orden</button></div></form></Modal> : null}

      {clientModalOpen ? <Modal title="Nuevo cliente" description="Crea una ficha de contacto en el CRM de Tecnoclinic." icon={UserPlus} onClose={() => setClientModalOpen(false)}><form onSubmit={(event) => void submitClient(event)}><div className="form-grid"><div className="form-field full"><label>Nombre completo *</label><input required value={clientDraft.name} onChange={(event) => setClientDraft((draft) => ({ ...draft, name: event.target.value }))} placeholder="Nombre y apellido" /></div><div className="form-field full"><label>Teléfono / WhatsApp *</label><input required value={clientDraft.phone} onChange={(event) => setClientDraft((draft) => ({ ...draft, phone: event.target.value }))} placeholder="+58 412 000 0000" /></div><div className="form-field full"><label>Correo electrónico</label><input type="email" value={clientDraft.email} onChange={(event) => setClientDraft((draft) => ({ ...draft, email: event.target.value }))} placeholder="cliente@correo.com" /></div><div className="form-field full"><label>Notas del cliente</label><textarea value={clientDraft.notes} onChange={(event) => setClientDraft((draft) => ({ ...draft, notes: event.target.value }))} placeholder="Preferencias de atención, observaciones…" /></div></div><div className="modal-footer"><button className="secondary-button" type="button" onClick={() => setClientModalOpen(false)}>Cancelar</button><button className="primary-button" type="submit" disabled={busy}>{busy ? <LoaderCircle size={14} className="animate-spin" /> : <UserPlus size={14} />}Guardar cliente</button></div></form></Modal> : null}

      {appointmentModalOpen ? <Modal title={appointmentSource === "assistant" ? "Agendar con el asistente" : "Nueva cita"} description="La hora se guardará en la zona horaria America/Caracas." icon={CalendarPlus} onClose={() => setAppointmentModalOpen(false)} wide><form onSubmit={(event) => void submitAppointment(event)}><div className="form-grid"><div className="form-field"><label>Nombre del cliente *</label><input required value={appointmentDraft.name} onChange={(event) => setAppointmentDraft((draft) => ({ ...draft, name: event.target.value }))} placeholder="Nombre y apellido" /></div><div className="form-field"><label>Teléfono / WhatsApp *</label><input required value={appointmentDraft.phone} onChange={(event) => setAppointmentDraft((draft) => ({ ...draft, phone: event.target.value }))} placeholder="+58 412 000 0000" /></div><div className="form-field"><label>Correo <span>opcional</span></label><input type="email" value={appointmentDraft.email} onChange={(event) => setAppointmentDraft((draft) => ({ ...draft, email: event.target.value }))} placeholder="cliente@correo.com" /></div><div className="form-field"><label>Servicio *</label><select required value={appointmentDraft.service} onChange={(event) => setAppointmentDraft((draft) => ({ ...draft, service: event.target.value }))}>{services.map((service) => <option key={service} value={service}>{service}</option>)}</select></div><div className="form-field"><label>Fecha y hora *</label><input type="datetime-local" required value={appointmentDraft.startsAt} onChange={(event) => setAppointmentDraft((draft) => ({ ...draft, startsAt: event.target.value }))} /></div><div className="form-field"><label>Placa <span>opcional</span></label><input value={appointmentDraft.plate} onChange={(event) => setAppointmentDraft((draft) => ({ ...draft, plate: event.target.value.toUpperCase() }))} placeholder="ABC123" /></div><div className="form-field"><label>Marca</label><input value={appointmentDraft.make} onChange={(event) => setAppointmentDraft((draft) => ({ ...draft, make: event.target.value }))} placeholder="Toyota" /></div><div className="form-field"><label>Modelo / año</label><div style={{ display: "flex", gap: 7 }}><input style={{ flex: 1 }} value={appointmentDraft.model} onChange={(event) => setAppointmentDraft((draft) => ({ ...draft, model: event.target.value }))} placeholder="Corolla" /><input style={{ width: 90 }} inputMode="numeric" value={appointmentDraft.year} onChange={(event) => setAppointmentDraft((draft) => ({ ...draft, year: event.target.value }))} placeholder="Año" /></div></div><div className="form-field full"><label>Notas</label><textarea value={appointmentDraft.notes} onChange={(event) => setAppointmentDraft((draft) => ({ ...draft, notes: event.target.value }))} placeholder="Detalles para el asesor o técnico…" /></div></div><div className="modal-footer"><button className="secondary-button" type="button" onClick={() => setAppointmentModalOpen(false)}>Cancelar</button><button className="primary-button" type="submit" disabled={busy}>{busy ? <LoaderCircle size={14} className="animate-spin" /> : <CalendarCheck size={14} />}{appointmentSource === "assistant" ? "Confirmar cita" : "Agendar cita"}</button></div></form></Modal> : null}

      {partModalOpen ? <Modal title="Agregar repuesto" description="Incluye la referencia en el inventario del taller." icon={Package} onClose={() => setPartModalOpen(false)}><form onSubmit={(event) => void submitPart(event)}><div className="form-grid"><div className="form-field"><label>Código / SKU *</label><input required value={partDraft.sku} onChange={(event) => setPartDraft((draft) => ({ ...draft, sku: event.target.value.toUpperCase() }))} placeholder="ACD-001" /></div><div className="form-field"><label>Marca</label><input value={partDraft.brand} onChange={(event) => setPartDraft((draft) => ({ ...draft, brand: event.target.value }))} placeholder="ACDelco" /></div><div className="form-field full"><label>Nombre del repuesto *</label><input required value={partDraft.name} onChange={(event) => setPartDraft((draft) => ({ ...draft, name: event.target.value }))} placeholder="Aceite sintético 5W-30" /></div><div className="form-field"><label>Categoría</label><select value={partDraft.category} onChange={(event) => setPartDraft((draft) => ({ ...draft, category: event.target.value }))}><option>Lubricantes</option><option>Encendido</option><option>Filtros</option><option>Frenos</option><option>Repuestos</option></select></div><div className="form-field"><label>Precio referencial · USD</label><input type="number" min="0" step="0.01" value={partDraft.price} onChange={(event) => setPartDraft((draft) => ({ ...draft, price: event.target.value }))} placeholder="0.00" /></div><div className="form-field"><label>Unidades disponibles</label><input type="number" min="0" step="1" value={partDraft.stock} onChange={(event) => setPartDraft((draft) => ({ ...draft, stock: event.target.value }))} /></div><div className="form-field"><label>Mínimo de inventario</label><input type="number" min="0" step="1" value={partDraft.minimumStock} onChange={(event) => setPartDraft((draft) => ({ ...draft, minimumStock: event.target.value }))} /></div><div className="form-field full"><label>Proveedor</label><input value={partDraft.supplier} onChange={(event) => setPartDraft((draft) => ({ ...draft, supplier: event.target.value }))} placeholder="Proveedor de repuestos" /></div></div><div className="modal-footer"><button className="secondary-button" type="button" onClick={() => setPartModalOpen(false)}>Cancelar</button><button className="primary-button" type="submit" disabled={busy}>{busy ? <LoaderCircle size={14} className="animate-spin" /> : <Plus size={14} />}Agregar al inventario</button></div></form></Modal> : null}

      {focusedOrder ? <Modal title={focusedOrder.code} description={`Orden registrada para ${focusedOrder.clientName}.`} icon={Wrench} onClose={() => setFocusedOrder(null)}><div className="form-grid"><div className="form-field full"><label>Cliente</label><div className="table-person"><Avatar name={focusedOrder.clientName} /><div><strong>{focusedOrder.clientName}</strong><span>{focusedOrder.phone}</span></div></div></div><div className="form-field"><label>Vehículo</label><input readOnly value={`${focusedOrder.vehicle} · ${focusedOrder.plate}`} /></div><div className="form-field"><label>Servicio</label><input readOnly value={focusedOrder.service} /></div><div className="form-field full"><label>Notas de servicio</label><textarea readOnly value={focusedOrder.description || "Sin notas adicionales."} /></div><div className="form-field"><label>Estado de la orden</label><select value={focusedOrder.status} onChange={(event) => { const status = event.target.value as WorkOrderStatus; changeOrderStatus(focusedOrder.id, status); setFocusedOrder({ ...focusedOrder, status }); }}>{statusColumns.map((column) => <option key={column.id} value={column.id}>{column.label}</option>)}</select></div><div className="form-field"><label>Asignado a</label><input readOnly value={focusedOrder.technician} /></div><div className="form-field"><label>Monto estimado</label><input readOnly value={focusedOrder.amount ? formatMoney(focusedOrder.amount) : "Pendiente de cotizar"} /></div><div className="form-field"><label>Última actividad</label><input readOnly value={formatRelative(focusedOrder.updatedAt)} /></div></div><div className="modal-footer"><button className="secondary-button" type="button" onClick={() => setFocusedOrder(null)}>Cerrar</button><button className="primary-button" type="button" onClick={() => { setFocusedOrder(null); goTo("inbox"); setSelectedConversationId(data.conversations.find((conversation) => conversation.customerId === focusedOrder.customerId)?.id ?? selectedConversationId); }}><MessageCircle size={13} />Abrir conversación</button></div></Modal> : null}

      {connectionModalOpen ? <Modal title="Conectar WhatsApp" description="Vincula el número del taller a la bandeja compartida." icon={QrCode} onClose={() => setConnectionModalOpen(false)} wide><div className="qr-layout"><div className="qr-box">{whatsAppStatus.qrDataUrl ? <NextImage src={whatsAppStatus.qrDataUrl} alt="Código QR para vincular WhatsApp" width={280} height={280} unoptimized /> : <div className="qr-placeholder">{whatsAppStatus.status === "connecting" ? <><LoaderCircle size={24} className="animate-spin" />Iniciando conexión segura…</> : whatsAppStatus.connected ? <><CheckCircle2 size={28} />WhatsApp está vinculado</> : <><QrCode size={30} />Presiona “Generar código QR” para vincular el número del taller.</>}</div>}</div><div className="qr-steps"><h3>Vincula tu dispositivo</h3><span className={`qr-status${whatsAppStatus.connected ? " connected" : ""}`}><i />{whatsAppStatus.connected ? `Conectado${whatsAppStatus.phoneNumber ? ` · +${whatsAppStatus.phoneNumber}` : ""}` : whatsAppStatus.status === "qr" ? "Esperando que escanees el código" : whatsAppStatus.status === "connecting" ? "Preparando el código QR" : "Desconectado"}</span><div className="qr-step"><b>1</b><span>Abre WhatsApp en el teléfono de Tecnoclinic.</span></div><div className="qr-step"><b>2</b><span>Ve a <strong>Dispositivos vinculados</strong> y elige “Vincular un dispositivo”.</span></div><div className="qr-step"><b>3</b><span>Escanea el código QR. La sesión se guarda en el servidor para reconectar automáticamente.</span></div><small className="form-help">Conexión no oficial de WhatsApp Web mediante Baileys. Mantén seguro el dispositivo vinculado.</small></div></div><div className="modal-footer">{whatsAppStatus.connected ? <button className="secondary-button" type="button" onClick={() => void disconnectWhatsApp()}><X size={13} />Desconectar</button> : <button className="primary-button" type="button" onClick={() => void connectWhatsApp()} disabled={whatsAppStatus.status === "connecting" || whatsAppStatus.status === "qr"}>{whatsAppStatus.status === "connecting" ? <LoaderCircle size={14} className="animate-spin" /> : <QrCode size={14} />}{whatsAppStatus.status === "qr" ? "Código QR listo" : whatsAppStatus.status === "connecting" ? "Conectando…" : "Generar código QR"}</button>}<button className="secondary-button" type="button" onClick={() => setConnectionModalOpen(false)}>Cerrar</button></div></Modal> : null}

      {toast ? <div className={`toast-stack`}><div className={`toast-message${toast.kind === "error" ? " error" : ""}`}><CheckCircle2 size={15} />{toast.message}</div></div> : null}
    </div>
  );
}
