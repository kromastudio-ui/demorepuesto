import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "TecnoClinic Hub | Gestión automotriz",
  description:
    "CRM, órdenes de trabajo, citas e inbox compartido de Tecnoclinic Repuestos en Maripérez, Caracas.",
  applicationName: "TecnoClinic Hub",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es">
      <body className="bg-[#f6f7f9] text-slate-900 antialiased">{children}</body>
    </html>
  );
}
