import { NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { automationRules } from "@/db/schema";

export const runtime = "nodejs";

export async function GET() {
  try {
    const rules = await db.select().from(automationRules).orderBy(asc(automationRules.id));
    return NextResponse.json({ automations: rules });
  } catch (error) {
    console.error("Error cargando automatizaciones:", error);
    return NextResponse.json({ error: "No fue posible cargar las automatizaciones." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as { key?: string; active?: boolean };
    if (!body.key || typeof body.active !== "boolean") {
      return NextResponse.json({ error: "Regla o estado no válido." }, { status: 400 });
    }
    const [updated] = await db
      .update(automationRules)
      .set({ active: body.active, updatedAt: new Date() })
      .where(eq(automationRules.key, body.key))
      .returning({ key: automationRules.key, active: automationRules.active });
    if (!updated) return NextResponse.json({ error: "Automatización no encontrada." }, { status: 404 });
    return NextResponse.json({ automation: updated });
  } catch (error) {
    console.error("Error guardando automatización:", error);
    return NextResponse.json({ error: "No fue posible guardar la automatización." }, { status: 500 });
  }
}
