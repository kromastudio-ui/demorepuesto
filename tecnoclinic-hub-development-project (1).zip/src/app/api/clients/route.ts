import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { getDashboardData } from "@/lib/app-data";

export const runtime = "nodejs";

export async function GET() {
  try {
    const data = await getDashboardData();
    return NextResponse.json({ customers: data.customers });
  } catch (error) {
    console.error("Error cargando clientes:", error);
    return NextResponse.json({ error: "No fue posible cargar los clientes." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const phone = typeof body.phone === "string" ? body.phone.trim() : "";
    if (!name || !phone) {
      return NextResponse.json({ error: "El nombre y teléfono son obligatorios." }, { status: 400 });
    }

    const [customer] = await db
      .insert(customers)
      .values({
        name,
        phone,
        email: typeof body.email === "string" ? body.email.trim() : null,
        notes: typeof body.notes === "string" ? body.notes.trim() : null,
      })
      .returning();

    return NextResponse.json({
      customer: {
        id: customer.id,
        name: customer.name,
        phone: customer.phone,
        email: customer.email ?? "",
        notes: customer.notes ?? "",
        vehicles: [],
        lastInteraction: customer.createdAt.toISOString(),
      },
    }, { status: 201 });
  } catch (error) {
    console.error("Error creando cliente:", error);
    return NextResponse.json({ error: "No fue posible crear el cliente." }, { status: 500 });
  }
}
