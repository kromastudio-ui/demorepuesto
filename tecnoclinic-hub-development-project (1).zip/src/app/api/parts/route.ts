import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { parts } from "@/db/schema";
import { getDashboardData } from "@/lib/app-data";

export const runtime = "nodejs";

export async function GET() {
  try {
    const data = await getDashboardData();
    return NextResponse.json({ parts: data.parts });
  } catch (error) {
    console.error("Error cargando inventario:", error);
    return NextResponse.json({ error: "No fue posible cargar el inventario." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const sku = typeof body.sku === "string" ? body.sku.trim() : "";
    const name = typeof body.name === "string" ? body.name.trim() : "";
    if (!sku || !name) return NextResponse.json({ error: "Código y nombre del repuesto son obligatorios." }, { status: 400 });

    const [created] = await db
      .insert(parts)
      .values({
        sku,
        name,
        brand: typeof body.brand === "string" ? body.brand : "Genérico",
        category: typeof body.category === "string" ? body.category : "Repuestos",
        stock: Number(body.stock ?? 0),
        minimumStock: Number(body.minimumStock ?? 3),
        price: String(Number(body.price ?? 0)),
        supplier: typeof body.supplier === "string" ? body.supplier : null,
      })
      .returning();

    return NextResponse.json({
      part: {
        id: created.id,
        sku: created.sku,
        name: created.name,
        brand: created.brand,
        category: created.category,
        stock: created.stock,
        minimumStock: created.minimumStock,
        price: Number(created.price),
        supplier: created.supplier ?? "—",
      },
    }, { status: 201 });
  } catch (error) {
    console.error("Error creando repuesto:", error);
    return NextResponse.json({ error: "No fue posible crear el repuesto. Verifica que el código no esté repetido." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as { id?: number; stock?: number };
    const id = Number(body.id);
    const stock = Number(body.stock);
    if (!Number.isInteger(id) || !Number.isInteger(stock) || stock < 0) {
      return NextResponse.json({ error: "Repuesto o cantidad no válida." }, { status: 400 });
    }
    const [updated] = await db
      .update(parts)
      .set({ stock, updatedAt: new Date() })
      .where(eq(parts.id, id))
      .returning({ id: parts.id });
    if (!updated) return NextResponse.json({ error: "Repuesto no encontrado." }, { status: 404 });
    return NextResponse.json({ ok: true, id, stock });
  } catch (error) {
    console.error("Error actualizando repuesto:", error);
    return NextResponse.json({ error: "No fue posible actualizar el stock." }, { status: 500 });
  }
}
