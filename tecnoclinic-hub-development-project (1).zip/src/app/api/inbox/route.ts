import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { conversations, customers, messages } from "@/db/schema";
import { getDashboardData } from "@/lib/app-data";
import { sendWhatsAppMessage } from "@/lib/whatsapp";

export const runtime = "nodejs";

export async function GET() {
  try {
    const data = await getDashboardData();
    return NextResponse.json({ conversations: data.conversations });
  } catch (error) {
    console.error("Error cargando inbox:", error);
    return NextResponse.json({ error: "No fue posible cargar las conversaciones." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as { id?: number; action?: string; assignee?: string };
    const id = Number(body.id);
    if (!Number.isInteger(id) || !["read", "assign", "resolve", "reopen"].includes(body.action || "")) {
      return NextResponse.json({ error: "Conversación o acción no válida." }, { status: 400 });
    }
    const changes = body.action === "read"
      ? { unreadCount: 0 }
      : body.action === "resolve"
        ? { status: "resolved", unreadCount: 0 }
        : body.action === "reopen"
          ? { status: "open" }
          : { assignee: body.assignee?.trim() || "Valentina R." };
    const [updated] = await db.update(conversations).set(changes).where(eq(conversations.id, id)).returning({ id: conversations.id, status: conversations.status, assignee: conversations.assignee, unreadCount: conversations.unreadCount });
    if (!updated) return NextResponse.json({ error: "Conversación no encontrada." }, { status: 404 });
    return NextResponse.json({ conversation: updated });
  } catch (error) {
    console.error("Error actualizando conversación:", error);
    return NextResponse.json({ error: "No fue posible actualizar la conversación." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { conversationId?: number; body?: string; author?: string };
    const conversationId = Number(body.conversationId);
    const text = typeof body.body === "string" ? body.body.trim() : "";
    if (!Number.isInteger(conversationId) || !text) {
      return NextResponse.json({ error: "Conversación y mensaje son obligatorios." }, { status: 400 });
    }

    const [record] = await db
      .select({ conversation: conversations, customer: customers })
      .from(conversations)
      .leftJoin(customers, eq(conversations.customerId, customers.id))
      .where(eq(conversations.id, conversationId))
      .limit(1);
    if (!record) return NextResponse.json({ error: "Conversación no encontrada." }, { status: 404 });

    let deliveryStatus = "queued";
    if (record.conversation.channel === "whatsapp" && record.customer?.phone) {
      try {
        const delivered = await sendWhatsAppMessage(record.customer.phone, text);
        if (delivered) deliveryStatus = "sent";
      } catch (error) {
        console.warn("Mensaje guardado para reintento; WhatsApp no disponible:", error);
      }
    }

    const sentAt = new Date();
    const [message] = await db
      .insert(messages)
      .values({
        conversationId,
        body: text,
        direction: "outgoing",
        author: body.author || "Valentina R.",
        deliveryStatus,
        sentAt,
      })
      .returning();

    await db
      .update(conversations)
      .set({ lastMessageAt: sentAt, status: "open", unreadCount: 0 })
      .where(eq(conversations.id, conversationId));

    return NextResponse.json({
      message: {
        id: message.id,
        conversationId,
        body: message.body,
        direction: "outgoing",
        author: message.author ?? "",
        deliveryStatus: message.deliveryStatus,
        sentAt: message.sentAt.toISOString(),
      },
    }, { status: 201 });
  } catch (error) {
    console.error("Error enviando mensaje:", error);
    return NextResponse.json({ error: "No fue posible enviar el mensaje." }, { status: 500 });
  }
}
