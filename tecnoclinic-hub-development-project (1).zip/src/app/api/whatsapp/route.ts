import { NextResponse } from "next/server";
import { getWhatsAppSnapshot, startWhatsApp, stopWhatsApp } from "@/lib/whatsapp";

export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json(getWhatsAppSnapshot());
}

export async function POST() {
  try {
    await startWhatsApp();
    return NextResponse.json(getWhatsAppSnapshot(), { status: 202 });
  } catch (error) {
    console.error("Error iniciando la conexión de WhatsApp:", error);
    return NextResponse.json({ error: "No se pudo iniciar WhatsApp Web. Intenta nuevamente." }, { status: 503 });
  }
}

export async function DELETE() {
  try {
    await stopWhatsApp();
    return NextResponse.json(getWhatsAppSnapshot());
  } catch (error) {
    console.error("Error cerrando la sesión de WhatsApp:", error);
    return NextResponse.json({ error: "No se pudo cerrar la sesión." }, { status: 500 });
  }
}
