import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { conversations, customers, messages } from "@/db/schema";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const webhookToken = process.env.WHATSAPP_WEBHOOK_TOKEN;
  if (webhookToken && request.headers.get("x-webhook-token") !== webhookToken) {
    return NextResponse.json({ error: "No autorizado." }, { status: 401 });
  }

  try {
    const body = (await request.json()) as {
      phone?: string;
      name?: string;
      text?: string;
      fromMe?: boolean;
      externalId?: string;
      timestamp?: string;
    };
    const phone = typeof body.phone === "string" ? body.phone.trim() : "";
    const text = typeof body.text === "string" ? body.text.trim() : "";
    if (!phone || !text) return NextResponse.json({ error: "Se requiere phone y text." }, { status: 400 });

    let customer = (await db.select().from(customers).where(eq(customers.phone, phone)).limit(1))[0];
    if (!customer) {
      customer = (
        await db.insert(customers).values({ name: body.name?.trim() || phone, phone }).returning()
      )[0];
    }

    let conversation = (
      await db
        .select()
        .from(conversations)
        .where(eq(conversations.customerId, customer.id))
        .limit(1)
    )[0];
    const receivedAt = body.timestamp ? new Date(body.timestamp) : new Date();
    if (!conversation) {
      conversation = (
        await db
          .insert(conversations)
          .values({
            customerId: customer.id,
            channel: "whatsapp",
            status: "open",
            assignee: "Sin asignar",
            unreadCount: 0,
            externalId: body.externalId ?? null,
            lastMessageAt: receivedAt,
          })
          .returning()
      )[0];
    }

    const direction = body.fromMe ? "outgoing" : "incoming";
    if (body.externalId) {
      const existing = await db.select({ id: messages.id }).from(messages).where(eq(messages.externalId, body.externalId)).limit(1);
      if (existing.length) return NextResponse.json({ ok: true, duplicate: true });
    }

    await db.insert(messages).values({
      conversationId: conversation.id,
      body: text,
      direction,
      author: body.fromMe ? "WhatsApp" : null,
      externalId: body.externalId ?? null,
      deliveryStatus: "received",
      sentAt: receivedAt,
    });
    await db
      .update(conversations)
      .set({
        lastMessageAt: receivedAt,
        status: "open",
        unreadCount: body.fromMe ? conversation.unreadCount : conversation.unreadCount + 1,
      })
      .where(eq(conversations.id, conversation.id));

    return NextResponse.json({ ok: true, conversationId: conversation.id }, { status: 202 });
  } catch (error) {
    console.error("Error procesando webhook de WhatsApp:", error);
    return NextResponse.json({ error: "No se pudo procesar el mensaje." }, { status: 500 });
  }
}
