import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { customers, vehicles, workOrders } from "@/db/schema";
import { getDashboardData } from "@/lib/app-data";
import type { WorkOrderStatus } from "@/lib/types";

export const runtime = "nodejs";

const allowedStatuses: WorkOrderStatus[] = [
  "por_cotizar",
  "cita_agendada",
  "diagnostico",
  "esperando_repuesto",
  "listo_entrega",
  "entregado",
];

export async function GET() {
  try {
    const data = await getDashboardData();
    return NextResponse.json({ workOrders: data.workOrders });
  } catch (error) {
    console.error("Error cargando órdenes:", error);
    return NextResponse.json({ error: "No fue posible cargar las órdenes." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const phone = typeof body.phone === "string" ? body.phone.trim() : "";
    const service = typeof body.service === "string" ? body.service.trim() : "";
    const plate = typeof body.plate === "string" ? body.plate.trim().toUpperCase() : "";
    const make = typeof body.make === "string" ? body.make.trim() : "";
    const model = typeof body.model === "string" ? body.model.trim() : "";

    if (!name || !phone || !service) {
      return NextResponse.json({ error: "Nombre, teléfono y servicio son obligatorios." }, { status: 400 });
    }

    let customer = (await db.select().from(customers).where(eq(customers.phone, phone)).limit(1))[0];
    if (!customer) {
      customer = (
        await db
          .insert(customers)
          .values({
            name,
            phone,
            email: typeof body.email === "string" ? body.email.trim() : null,
          })
          .returning()
      )[0];
    }

    let vehicleId: number | null = null;
    let vehicle = plate
      ? (await db.select().from(vehicles).where(eq(vehicles.plate, plate)).limit(1))[0]
      : undefined;
    if (vehicle) {
      vehicleId = vehicle.id;
    } else if (make && model && plate) {
      vehicle = (
        await db
          .insert(vehicles)
          .values({
            customerId: customer.id,
            make,
            model,
            year: typeof body.year === "number" ? body.year : null,
            plate,
          })
          .returning()
      )[0];
      vehicleId = vehicle.id;
    }

    const latest = (await db.select({ code: workOrders.code }).from(workOrders).orderBy(desc(workOrders.id)).limit(1))[0];
    const previousNumber = latest ? Number(latest.code.replace(/\D/g, "")) : 240;
    const status = typeof body.status === "string" && allowedStatuses.includes(body.status as WorkOrderStatus)
      ? (body.status as WorkOrderStatus)
      : "por_cotizar";
    const inserted = await db
      .insert(workOrders)
      .values({
        code: `TC-${String(previousNumber + 1).padStart(4, "0")}`,
        customerId: customer.id,
        vehicleId,
        service,
        description: typeof body.description === "string" ? body.description.trim() : "",
        status,
        priority: body.priority === "alta" ? "alta" : "normal",
        technician: typeof body.technician === "string" ? body.technician : "Sin asignar",
        amount: typeof body.amount === "number" ? String(body.amount) : "0",
      })
      .returning();

    const data = await getDashboardData();
    const order = data.workOrders.find((item) => item.id === inserted[0].id);
    return NextResponse.json({ workOrder: order }, { status: 201 });
  } catch (error) {
    console.error("Error creando orden:", error);
    return NextResponse.json({ error: "No fue posible crear la orden." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as { id?: number; status?: string; technician?: string; priority?: string };
    const id = Number(body.id);
    if (!Number.isInteger(id) || !body.status || !allowedStatuses.includes(body.status as WorkOrderStatus)) {
      return NextResponse.json({ error: "Orden o estado no válido." }, { status: 400 });
    }

    const updated = await db
      .update(workOrders)
      .set({
        status: body.status,
        ...(typeof body.technician === "string" ? { technician: body.technician } : {}),
        ...(typeof body.priority === "string" ? { priority: body.priority } : {}),
        updatedAt: new Date(),
      })
      .where(eq(workOrders.id, id))
      .returning({ id: workOrders.id });

    if (!updated.length) return NextResponse.json({ error: "Orden no encontrada." }, { status: 404 });
    return NextResponse.json({ ok: true, id, status: body.status });
  } catch (error) {
    console.error("Error actualizando orden:", error);
    return NextResponse.json({ error: "No fue posible actualizar la orden." }, { status: 500 });
  }
}
