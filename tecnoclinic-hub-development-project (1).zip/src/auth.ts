import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";

export const { handlers, auth, signIn, signOut } = NextAuth({
  secret: process.env.AUTH_SECRET || process.env.NEXTAUTH_SECRET,
  session: { strategy: "jwt" },
  pages: { signIn: "/login" },
  providers: [
    Credentials({
      name: "Correo y contraseña",
      credentials: {
        email: { label: "Correo electrónico", type: "email" },
        password: { label: "Contraseña", type: "password" },
      },
      async authorize(credentials) {
        const email = typeof credentials?.email === "string" ? credentials.email.trim().toLowerCase() : "";
        const password = typeof credentials?.password === "string" ? credentials.password : "";
        if (!email || !password) return null;

        let user = (await db.select().from(users).where(eq(users.email, email)).limit(1))[0];
        const bootstrapEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
        const bootstrapPassword = process.env.ADMIN_PASSWORD;
        if (!user && bootstrapEmail === email && bootstrapPassword && bootstrapPassword === password) {
          const [created] = await db
            .insert(users)
            .values({
              name: process.env.ADMIN_NAME?.trim() || "Administrador TecnoClinic",
              email,
              passwordHash: await bcrypt.hash(password, 12),
              role: "admin",
            })
            .onConflictDoNothing()
            .returning();
          user = created ?? (await db.select().from(users).where(eq(users.email, email)).limit(1))[0];
        }
        if (!user?.active || !(await bcrypt.compare(password, user.passwordHash))) return null;
        return {
          id: String(user.id),
          name: user.name,
          email: user.email,
          role: user.role,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = (user as typeof user & { role?: string }).role ?? "advisor";
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = String(token.id ?? token.sub ?? "");
        session.user.role = String(token.role ?? "advisor");
      }
      return session;
    },
  },
});
