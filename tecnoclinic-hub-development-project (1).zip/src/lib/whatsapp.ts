import { mkdir } from "node:fs/promises";
import path from "node:path";
import makeWASocket, { DisconnectReason } from "@whiskeysockets/baileys";
import QRCode from "qrcode";
import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { automationRules, conversations, customers, messages } from "@/db/schema";
import { answerCustomerQuestion } from "@/lib/assistant-engine";

type Socket = ReturnType<typeof makeWASocket>;
type WhatsAppStatus = "disconnected" | "connecting" | "qr" | "connected";
type WhatsAppRuntime = {
  status: WhatsAppStatus;
  qrDataUrl: string | null;
  phoneNumber: string | null;
  socket: Socket | null;
  starting: Promise<void> | null;
  reconnectTimer: ReturnType<typeof setTimeout> | null;
  manualDisconnect: boolean;
};

const globalForWhatsApp = globalThis as typeof globalThis & { __tecnoclinicWhatsApp?: WhatsAppRuntime };
const runtime: WhatsAppRuntime =
  globalForWhatsApp.__tecnoclinicWhatsApp ?? {
    status: "disconnected",
    qrDataUrl: null,
    phoneNumber: null,
    socket: null,
    starting: null,
    reconnectTimer: null,
    manualDisconnect: false,
  };
globalForWhatsApp.__tecnoclinicWhatsApp = runtime;

export function getWhatsAppSnapshot() {
  return {
    status: runtime.status,
    qrDataUrl: runtime.qrDataUrl,
    phoneNumber: runtime.phoneNumber,
    connected: runtime.status === "connected",
  };
}

function getMessageText(message: { message?: unknown | null }) {
  const content = message.message as Record<string, unknown> | undefined;
  if (!content) return "";
  const conversation = content.conversation;
  const extended = content.extendedTextMessage as { text?: string } | undefined;
  const image = content.imageMessage as { caption?: string } | undefined;
  const video = content.videoMessage as { caption?: string } | undefined;
  const document = content.documentMessage as { caption?: string; fileName?: string } | undefined;
  if (typeof conversation === "string") return conversation;
  if (extended?.text) return extended.text;
  if (image?.caption) return image.caption;
  if (video?.caption) return video.caption;
  if (document?.caption) return document.caption;
  if (image) return "📷 Imagen recibida";
  if (video) return "🎥 Video recibido";
  if (document) return `📎 ${document.fileName || "Documento recibido"}`;
  return "";
}

async function saveIncomingMessage(phone: string, name: string, text: string, externalId?: string) {
  const digits = phone.replace(/\D/g, "");
  if (!digits || !text.trim()) return null;

  const allCustomers = await db.select().from(customers);
  let customer = allCustomers.find((item) => item.phone.replace(/\D/g, "") === digits);
  if (!customer) {
    customer = (
      await db.insert(customers).values({ name: name || `+${digits}`, phone: `+${digits}` }).returning()
    )[0];
  }

  let conversation = (
    await db.select().from(conversations).where(eq(conversations.customerId, customer.id)).limit(1)
  )[0];
  const receivedAt = new Date();
  if (!conversation) {
    conversation = (
      await db
        .insert(conversations)
        .values({
          customerId: customer.id,
          channel: "whatsapp",
          status: "open",
          assignee: "Sin asignar",
          unreadCount: 0,
          externalId: phone,
          lastMessageAt: receivedAt,
        })
        .returning()
    )[0];
  }

  if (externalId) {
    const duplicate = await db.select({ id: messages.id }).from(messages).where(eq(messages.externalId, externalId)).limit(1);
    if (duplicate.length) return null;
  }

  await db.insert(messages).values({
    conversationId: conversation.id,
    body: text,
    direction: "incoming",
    externalId: externalId ?? null,
    deliveryStatus: "received",
    sentAt: receivedAt,
  });
  await db
    .update(conversations)
    .set({ lastMessageAt: receivedAt, status: "open", unreadCount: conversation.unreadCount + 1 })
    .where(eq(conversations.id, conversation.id));
  return { conversationId: conversation.id };
}

async function dispatchQueuedMessages(socket: Socket) {
  try {
    const queued = await db
      .select({ id: messages.id, body: messages.body, phone: customers.phone })
      .from(messages)
      .innerJoin(conversations, eq(messages.conversationId, conversations.id))
      .innerJoin(customers, eq(conversations.customerId, customers.id))
      .where(and(eq(messages.deliveryStatus, "queued"), eq(messages.direction, "outgoing")))
      .orderBy(asc(messages.sentAt))
      .limit(40);

    for (const item of queued) {
      if (runtime.socket !== socket || runtime.status !== "connected") return;
      const digits = item.phone.replace(/\D/g, "");
      if (!digits) continue;
      try {
        await socket.sendMessage(`${digits}@s.whatsapp.net`, { text: item.body });
        await db.update(messages).set({ deliveryStatus: "sent" }).where(eq(messages.id, item.id));
      } catch (error) {
        console.warn("Mensaje en cola; se reintentará en la próxima conexión:", error);
        return;
      }
    }
  } catch (error) {
    console.error("No se pudo despachar la cola de WhatsApp:", error);
  }
}

async function sendAutomaticReply(socket: Socket, phone: string, customerName: string, messageText: string, conversationId: number) {
  const rule = (
    await db
      .select({ active: automationRules.active })
      .from(automationRules)
      .where(and(eq(automationRules.key, "ai_whatsapp"), eq(automationRules.active, true)))
      .limit(1)
  )[0];
  if (!rule?.active || runtime.socket !== socket || runtime.status !== "connected") return;

  const reply = await answerCustomerQuestion(messageText, customerName);
  const digits = phone.replace(/\D/g, "");
  if (!digits || runtime.socket !== socket || runtime.status !== "connected") return;
  await socket.sendMessage(`${digits}@s.whatsapp.net`, { text: reply });
  const sentAt = new Date();
  await db.insert(messages).values({
    conversationId,
    body: reply,
    direction: "outgoing",
    author: "Asistente IA",
    deliveryStatus: "sent",
    sentAt,
  });
  await db.update(conversations).set({ lastMessageAt: sentAt }).where(eq(conversations.id, conversationId));
}

export async function startWhatsApp() {
  if (runtime.status === "connected" || runtime.status === "qr" || runtime.starting) return;
  runtime.manualDisconnect = false;
  runtime.status = "connecting";
  runtime.qrDataUrl = null;

  runtime.starting = (async () => {
    const authDirectory = process.env.WHATSAPP_AUTH_DIR || path.join(process.cwd(), "data", "whatsapp-auth");
    await mkdir(authDirectory, { recursive: true });
    const { state, saveCreds } = await import("@whiskeysockets/baileys").then(({ useMultiFileAuthState }) =>
      useMultiFileAuthState(authDirectory),
    );

    const socket = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      browser: ["TecnoClinic Hub", "Chrome", "1.0.0"],
    });
    runtime.socket = socket;
    socket.ev.on("creds.update", saveCreds);
    socket.ev.on("connection.update", async ({ connection, lastDisconnect, qr }) => {
      if (qr) {
        runtime.status = "qr";
        try {
          runtime.qrDataUrl = await QRCode.toDataURL(qr, { width: 280, margin: 1, color: { dark: "#111827", light: "#ffffff" } });
        } catch (error) {
          console.error("No se pudo generar el QR:", error);
        }
      }
      if (connection === "open") {
        runtime.status = "connected";
        runtime.qrDataUrl = null;
        runtime.phoneNumber = socket.user?.id?.split(":")[0]?.replace(/\D/g, "") ?? null;
        void dispatchQueuedMessages(socket);
      }
      if (connection === "close") {
        runtime.socket = null;
        runtime.status = "disconnected";
        runtime.qrDataUrl = null;
        runtime.phoneNumber = null;
        const error = lastDisconnect?.error as { output?: { statusCode?: number } } | undefined;
        const loggedOut = error?.output?.statusCode === DisconnectReason.loggedOut;
        if (!loggedOut && !runtime.manualDisconnect && !runtime.reconnectTimer) {
          runtime.reconnectTimer = setTimeout(() => {
            runtime.reconnectTimer = null;
            void startWhatsApp();
          }, 1800);
        }
      }
    });

    socket.ev.on("messages.upsert", async ({ messages: incoming, type }) => {
      if (type !== "notify") return;
      for (const message of incoming) {
        const remoteJid = message.key.remoteJid;
        if (message.key.fromMe || !remoteJid || remoteJid.endsWith("@g.us")) continue;
        const phone = remoteJid.split("@")[0].split(":")[0];
        const text = getMessageText(message);
        try {
          const saved = await saveIncomingMessage(phone, message.pushName ?? `+${phone}`, text, message.key.id ?? undefined);
          if (saved) await sendAutomaticReply(socket, phone, message.pushName ?? `+${phone}`, text, saved.conversationId);
        } catch (error) {
          console.error("No se pudo procesar el mensaje entrante de WhatsApp:", error);
        }
      }
    });
  })()
    .catch((error) => {
      runtime.status = "disconnected";
      console.error("No se pudo iniciar Baileys:", error);
      throw error;
    })
    .finally(() => {
      runtime.starting = null;
    });

  await runtime.starting;
}

export async function sendWhatsAppMessage(phone: string, text: string) {
  if (!runtime.socket || runtime.status !== "connected") return false;
  const digits = phone.replace(/\D/g, "");
  if (!digits) return false;
  await runtime.socket.sendMessage(`${digits}@s.whatsapp.net`, { text });
  return true;
}

export async function stopWhatsApp() {
  runtime.manualDisconnect = true;
  if (runtime.reconnectTimer) {
    clearTimeout(runtime.reconnectTimer);
    runtime.reconnectTimer = null;
  }
  if (runtime.socket) {
    const socket = runtime.socket;
    runtime.socket = null;
    try {
      await socket.logout();
    } catch (error) {
      console.warn("La sesión de WhatsApp ya estaba cerrada:", error);
    }
  }
  runtime.status = "disconnected";
  runtime.qrDataUrl = null;
  runtime.phoneNumber = null;
}
