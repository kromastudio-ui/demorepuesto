import bcrypt from "bcryptjs";
import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  appointments,
  automationRules,
  conversations,
  customers,
  messages,
  parts,
  vehicles,
  workOrders,
  users,
} from "@/db/schema";
import type {
  AppointmentRecord,
  ConversationRecord,
  CustomerRecord,
  DashboardData,
  MessageRecord,
  PartRecord,
  VehicleRecord,
  WorkOrderRecord,
} from "@/lib/types";

const ago = (hours: number, minutes = 0) => new Date(Date.now() - hours * 60 * 60 * 1000 - minutes * 60 * 1000);
const fromNow = (hours: number) => new Date(Date.now() + hours * 60 * 60 * 1000);

function todayAt(hour: number, minute: number) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Caracas",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return new Date(`${values.year}-${values.month}-${values.day}T${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}:00-04:00`);
}

async function seedDemoData() {
  const adminEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const adminPassword = process.env.ADMIN_PASSWORD;
  if (adminEmail && adminPassword) {
    const existingAdmin = await db.select({ id: users.id }).from(users).where(eq(users.email, adminEmail)).limit(1);
    if (!existingAdmin.length) {
      await db.insert(users).values({
        name: process.env.ADMIN_NAME?.trim() || "Administrador TecnoClinic",
        email: adminEmail,
        passwordHash: await bcrypt.hash(adminPassword, 12),
        role: "admin",
      });
    }
  }

  const existingRules = await db.select({ key: automationRules.key }).from(automationRules).limit(1);
  if (!existingRules.length) {
    await db.insert(automationRules).values([
      { key: "ai_whatsapp", title: "Asistente IA en WhatsApp", description: "Responde consultas frecuentes y deriva a un asesor cuando hace falta.", active: false },
      { key: "appointment_reminders", title: "Recordatorios de citas", description: "Prepara recordatorios para confirmar las visitas del día siguiente.", active: true },
      { key: "quote_followup", title: "Seguimiento de cotizaciones", description: "Crea una tarea si una cotización queda pendiente por más de 24 horas.", active: true },
    ]);
  }

  const existing = await db.select({ id: customers.id }).from(customers).limit(1);
  if (existing.length) return;

  const customerRows = await db
    .insert(customers)
    .values([
      { name: "Daniela Fernández", phone: "+58 412 331 9077", email: "daniela.fernandez@gmail.com", notes: "Prefiere atención por WhatsApp." },
      { name: "Carlos Azuaje", phone: "+58 414 812 6309", email: "carlos.azuaje@gmail.com", notes: "Cliente frecuente." },
      { name: "Sofía Marcano", phone: "+58 424 501 2387", email: "sofia.marcano@gmail.com", notes: "Confirmar repuesto antes de la visita." },
      { name: "Luis Rodríguez", phone: "+58 412 064 1180", email: "luis.rodriguez@gmail.com", notes: "" },
      { name: "Andrés Salazar", phone: "+58 414 260 7843", email: "andres.salazar@gmail.com", notes: "" },
      { name: "Paula Berrizbeitia", phone: "+58 424 247 9395", email: "paula.b@gmail.com", notes: "Solicita cotizaciones detalladas." },
      { name: "Samuel Cabrera", phone: "+58 412 513 9011", email: "samuel.cabrera@gmail.com", notes: "" },
      { name: "Valeria Pérez", phone: "+58 414 614 9332", email: "valeria.perez@gmail.com", notes: "" },
    ])
    .returning();

  const customerId = new Map(customerRows.map((customer) => [customer.name, customer.id]));
  const vehicleRows = await db
    .insert(vehicles)
    .values([
      { customerId: customerId.get("Daniela Fernández")!, make: "Toyota", model: "Corolla", year: 2016, plate: "AF983YK", color: "Gris" },
      { customerId: customerId.get("Carlos Azuaje")!, make: "Chevrolet", model: "Aveo", year: 2014, plate: "AF351LJ", color: "Blanco" },
      { customerId: customerId.get("Sofía Marcano")!, make: "Mazda", model: "3", year: 2015, plate: "ACR59B", color: "Rojo" },
      { customerId: customerId.get("Luis Rodríguez")!, make: "Ford", model: "Fiesta", year: 2013, plate: "ABL88M", color: "Azul" },
      { customerId: customerId.get("Andrés Salazar")!, make: "Toyota", model: "Fortuner", year: 2018, plate: "AC452MM", color: "Negro" },
      { customerId: customerId.get("Paula Berrizbeitia")!, make: "Chevrolet", model: "Cruze", year: 2016, plate: "ABM54G", color: "Plata" },
      { customerId: customerId.get("Samuel Cabrera")!, make: "Hyundai", model: "Elantra", year: 2017, plate: "AF309NT", color: "Blanco" },
      { customerId: customerId.get("Valeria Pérez")!, make: "Honda", model: "Civic", year: 2014, plate: "AC481EK", color: "Gris" },
    ])
    .returning();

  const vehicleId = new Map(vehicleRows.map((vehicle) => [vehicle.plate, vehicle.id]));
  await db.insert(workOrders).values([
    {
      code: "TC-0248",
      customerId: customerId.get("Daniela Fernández")!,
      vehicleId: vehicleId.get("AF983YK")!,
      service: "Limpieza de inyectores",
      description: "Laboratorio · prueba de caudal incluida",
      status: "diagnostico",
      priority: "alta",
      technician: "José A.",
      amount: "48.00",
      createdAt: ago(2, 12),
      updatedAt: ago(0, 18),
    },
    {
      code: "TC-0247",
      customerId: customerId.get("Carlos Azuaje")!,
      vehicleId: vehicleId.get("AF351LJ")!,
      service: "Escáner computarizado",
      description: "Cita confirmada por WhatsApp",
      status: "cita_agendada",
      priority: "normal",
      technician: "Marcos R.",
      amount: "35.00",
      createdAt: ago(4, 35),
      updatedAt: ago(1, 10),
    },
    {
      code: "TC-0246",
      customerId: customerId.get("Sofía Marcano")!,
      vehicleId: vehicleId.get("ACR59B")!,
      service: "Bujías iridium NGK",
      description: "Pendiente confirmar existencia con proveedor",
      status: "esperando_repuesto",
      priority: "normal",
      technician: "José A.",
      amount: "62.00",
      createdAt: ago(22),
      updatedAt: ago(3, 5),
    },
    {
      code: "TC-0245",
      customerId: customerId.get("Luis Rodríguez")!,
      vehicleId: vehicleId.get("ABL88M")!,
      service: "Mecánica rápida · frenos",
      description: "Pastillas delanteras instaladas, listo para entregar",
      status: "listo_entrega",
      priority: "normal",
      technician: "Carlos M.",
      amount: "95.00",
      createdAt: ago(1, 17),
      updatedAt: ago(0, 32),
    },
    {
      code: "TC-0244",
      customerId: customerId.get("Andrés Salazar")!,
      vehicleId: vehicleId.get("AC452MM")!,
      service: "Cambio de aceite ACDelco",
      description: "Servicio completado y facturado",
      status: "entregado",
      priority: "normal",
      technician: "Marcos R.",
      amount: "72.00",
      createdAt: ago(28),
      updatedAt: ago(2, 40),
    },
    {
      code: "TC-0243",
      customerId: customerId.get("Paula Berrizbeitia")!,
      vehicleId: vehicleId.get("ABM54G")!,
      service: "Tren delantero · cotización",
      description: "Revisar terminales y amortiguadores",
      status: "por_cotizar",
      priority: "alta",
      technician: "Valentina R.",
      amount: "0.00",
      createdAt: ago(0, 48),
      updatedAt: ago(0, 11),
    },
    {
      code: "TC-0242",
      customerId: customerId.get("Samuel Cabrera")!,
      vehicleId: vehicleId.get("AF309NT")!,
      service: "Diagnóstico de motor",
      description: "Luz de check engine encendida",
      status: "diagnostico",
      priority: "normal",
      technician: "José A.",
      amount: "25.00",
      createdAt: ago(5, 20),
      updatedAt: ago(0, 55),
    },
    {
      code: "TC-0241",
      customerId: customerId.get("Valeria Pérez")!,
      vehicleId: vehicleId.get("AC481EK")!,
      service: "Afinación y filtros",
      description: "Confirmar disponibilidad de filtro de aire",
      status: "por_cotizar",
      priority: "baja",
      technician: "Valentina R.",
      amount: "58.00",
      createdAt: ago(1, 45),
      updatedAt: ago(0, 40),
    },
  ]);

  await db.insert(parts).values([
    { sku: "ACD-5W30-01", name: "Aceite sintético 5W-30 · 1 qt", brand: "ACDelco", category: "Lubricantes", stock: 24, minimumStock: 6, price: "12.50", supplier: "Repuestos La Urbina" },
    { sku: "NGK-BKR6E", name: "Bujía estándar BKR6E", brand: "NGK", category: "Encendido", stock: 18, minimumStock: 8, price: "8.75", supplier: "Auto Partes Centro" },
    { sku: "ACD-FILT-041", name: "Filtro de aceite PF46E", brand: "ACDelco", category: "Filtros", stock: 4, minimumStock: 6, price: "9.20", supplier: "Repuestos La Urbina" },
    { sku: "MOB-10W40-04", name: "Aceite semisintético 10W-40 · 1 qt", brand: "Mobil", category: "Lubricantes", stock: 12, minimumStock: 5, price: "10.90", supplier: "LubriCaracas" },
    { sku: "ACD-PAD-210", name: "Pastillas de freno delanteras", brand: "ACDelco", category: "Frenos", stock: 2, minimumStock: 4, price: "42.00", supplier: "Repuestos La Urbina" },
    { sku: "DENSO-IK20", name: "Bujía iridium IK20", brand: "Denso", category: "Encendido", stock: 0, minimumStock: 4, price: "19.50", supplier: "Auto Partes Centro" },
  ]);

  const appointmentRows = await db
    .insert(appointments)
    .values([
      {
        customerId: customerId.get("Carlos Azuaje")!,
        vehicleId: vehicleId.get("AF351LJ")!,
        service: "Escáner computarizado",
        startsAt: todayAt(10, 30),
        durationMinutes: 60,
        status: "confirmada",
        notes: "Cliente confirmó por WhatsApp",
        assignedTo: "Marcos R.",
      },
      {
        customerId: customerId.get("Paula Berrizbeitia")!,
        vehicleId: vehicleId.get("ABM54G")!,
        service: "Revisión de tren delantero",
        startsAt: todayAt(13, 0),
        durationMinutes: 90,
        status: "pendiente",
        notes: "Enviar cotización antes de la visita",
        assignedTo: "José A.",
      },
      {
        customerId: customerId.get("Samuel Cabrera")!,
        vehicleId: vehicleId.get("AF309NT")!,
        service: "Diagnóstico de motor",
        startsAt: fromNow(26),
        durationMinutes: 60,
        status: "confirmada",
        notes: "",
        assignedTo: "Valentina R.",
      },
      {
        customerId: customerId.get("Valeria Pérez")!,
        vehicleId: vehicleId.get("AC481EK")!,
        service: "Afinación y filtros",
        startsAt: fromNow(51),
        durationMinutes: 120,
        status: "confirmada",
        notes: "",
        assignedTo: "Marcos R.",
      },
    ])
    .returning();

  const conversationRows = await db
    .insert(conversations)
    .values([
      { customerId: customerId.get("Carlos Azuaje")!, channel: "whatsapp", status: "open", assignee: "Valentina R.", unreadCount: 2, lastMessageAt: ago(0, 8) },
      { customerId: customerId.get("Sofía Marcano")!, channel: "whatsapp", status: "open", assignee: "José A.", unreadCount: 1, lastMessageAt: ago(0, 24) },
      { customerId: customerId.get("Paula Berrizbeitia")!, channel: "whatsapp", status: "open", assignee: "Sin asignar", unreadCount: 0, lastMessageAt: ago(1, 15) },
      { customerId: customerId.get("Valeria Pérez")!, channel: "whatsapp", status: "resolved", assignee: "Marcos R.", unreadCount: 0, lastMessageAt: ago(5, 30) },
    ])
    .returning();

  const conversationId = new Map(conversationRows.map((conversation) => [conversation.customerId, conversation.id]));
  const carlos = conversationId.get(customerId.get("Carlos Azuaje")!)!;
  const sofia = conversationId.get(customerId.get("Sofía Marcano")!)!;
  const paula = conversationId.get(customerId.get("Paula Berrizbeitia")!)!;
  const valeria = conversationId.get(customerId.get("Valeria Pérez")!)!;

  await db.insert(messages).values([
    { conversationId: carlos, direction: "incoming", body: "Hola, buenas. ¿Tienen disponibilidad para escanear mi Aveo hoy?", sentAt: ago(0, 16) },
    { conversationId: carlos, direction: "outgoing", author: "Valentina R.", body: "¡Hola, Carlos! Sí, tenemos un espacio a las 10:30 a. m. ¿Te funciona?", sentAt: ago(0, 13) },
    { conversationId: carlos, direction: "incoming", body: "Perfecto, ahí estaré. ¿Cuánto cuesta el diagnóstico?", sentAt: ago(0, 8) },
    { conversationId: sofia, direction: "incoming", body: "¿Me confirman si llegaron las bujías iridium para mi Mazda?", sentAt: ago(0, 24) },
    { conversationId: paula, direction: "incoming", body: "Buenas tardes, ¿me pueden enviar la cotización del tren delantero?", sentAt: ago(1, 15) },
    { conversationId: valeria, direction: "incoming", body: "Gracias, quedó excelente el servicio. 😊", sentAt: ago(5, 40) },
    { conversationId: valeria, direction: "outgoing", author: "Marcos R.", body: "¡Gracias a ti, Valeria! Cuenta con nosotros para tu próximo servicio.", sentAt: ago(5, 30) },
  ]);

  // The seed appointment insert is intentionally exercised here so a fresh install
  // has a stable set of agenda records alongside its sample orders and customers.
  void appointmentRows;
}

export async function getDashboardData(): Promise<DashboardData> {
  await seedDemoData();

  const [orderRows, customerRows, vehicleRows, appointmentRows, partRows, conversationRows, messageRows] = await Promise.all([
    db
      .select({ order: workOrders, customer: customers, vehicle: vehicles })
      .from(workOrders)
      .innerJoin(customers, eq(workOrders.customerId, customers.id))
      .leftJoin(vehicles, eq(workOrders.vehicleId, vehicles.id))
      .orderBy(desc(workOrders.updatedAt)),
    db.select().from(customers).orderBy(asc(customers.name)),
    db
      .select({ vehicle: vehicles, customer: customers })
      .from(vehicles)
      .innerJoin(customers, eq(vehicles.customerId, customers.id))
      .orderBy(asc(vehicles.make), asc(vehicles.model)),
    db
      .select({ appointment: appointments, customer: customers, vehicle: vehicles })
      .from(appointments)
      .innerJoin(customers, eq(appointments.customerId, customers.id))
      .leftJoin(vehicles, eq(appointments.vehicleId, vehicles.id))
      .orderBy(asc(appointments.startsAt)),
    db.select().from(parts).orderBy(asc(parts.name)),
    db
      .select({ conversation: conversations, customer: customers })
      .from(conversations)
      .leftJoin(customers, eq(conversations.customerId, customers.id))
      .orderBy(desc(conversations.lastMessageAt)),
    db.select().from(messages).orderBy(asc(messages.sentAt)),
  ]);

  const vehicleData: VehicleRecord[] = vehicleRows.map(({ vehicle, customer }) => ({
    id: vehicle.id,
    customerId: vehicle.customerId,
    customerName: customer.name,
    phone: customer.phone,
    make: vehicle.make,
    model: vehicle.model,
    year: vehicle.year,
    plate: vehicle.plate,
    color: vehicle.color ?? "",
  }));

  const vehiclesByCustomer = new Map<number, CustomerRecord["vehicles"]>();
  for (const vehicle of vehicleData) {
    const items = vehiclesByCustomer.get(vehicle.customerId) ?? [];
    items.push({ id: vehicle.id, make: vehicle.make, model: vehicle.model, year: vehicle.year, plate: vehicle.plate });
    vehiclesByCustomer.set(vehicle.customerId, items);
  }

  const lastInteractionByCustomer = new Map<number, Date>();
  for (const row of orderRows) {
    const current = lastInteractionByCustomer.get(row.customer.id);
    if (!current || row.order.updatedAt > current) lastInteractionByCustomer.set(row.customer.id, row.order.updatedAt);
  }

  const customerData: CustomerRecord[] = customerRows.map((customer) => ({
    id: customer.id,
    name: customer.name,
    phone: customer.phone,
    email: customer.email ?? "",
    notes: customer.notes ?? "",
    vehicles: vehiclesByCustomer.get(customer.id) ?? [],
    lastInteraction: (lastInteractionByCustomer.get(customer.id) ?? customer.createdAt).toISOString(),
  }));

  const workOrderData: WorkOrderRecord[] = orderRows.map(({ order, customer, vehicle }) => ({
    id: order.id,
    code: order.code,
    customerId: customer.id,
    clientName: customer.name,
    phone: customer.phone,
    vehicleId: vehicle?.id ?? null,
    vehicle: vehicle ? `${vehicle.make} ${vehicle.model}${vehicle.year ? ` ${vehicle.year}` : ""}` : "Vehículo sin registrar",
    plate: vehicle?.plate ?? "—",
    service: order.service,
    description: order.description ?? "",
    status: order.status as WorkOrderRecord["status"],
    priority: order.priority,
    technician: order.technician ?? "Sin asignar",
    amount: Number(order.amount ?? 0),
    createdAt: order.createdAt.toISOString(),
    updatedAt: order.updatedAt.toISOString(),
  }));

  const appointmentData: AppointmentRecord[] = appointmentRows.map(({ appointment, customer, vehicle }) => ({
    id: appointment.id,
    customerId: customer.id,
    customerName: customer.name,
    phone: customer.phone,
    vehicleId: vehicle?.id ?? null,
    vehicle: vehicle ? `${vehicle.make} ${vehicle.model}${vehicle.year ? ` ${vehicle.year}` : ""}` : "Vehículo sin registrar",
    plate: vehicle?.plate ?? "—",
    service: appointment.service,
    startsAt: appointment.startsAt.toISOString(),
    durationMinutes: appointment.durationMinutes,
    status: appointment.status,
    notes: appointment.notes ?? "",
    assignedTo: appointment.assignedTo ?? "Sin asignar",
  }));

  const partData: PartRecord[] = partRows.map((part) => ({
    id: part.id,
    sku: part.sku,
    name: part.name,
    brand: part.brand,
    category: part.category,
    stock: part.stock,
    minimumStock: part.minimumStock,
    price: Number(part.price ?? 0),
    supplier: part.supplier ?? "—",
  }));

  const messagesByConversation = new Map<number, MessageRecord[]>();
  for (const message of messageRows) {
    const group = messagesByConversation.get(message.conversationId) ?? [];
    group.push({
      id: message.id,
      conversationId: message.conversationId,
      body: message.body,
      direction: message.direction as MessageRecord["direction"],
      author: message.author ?? "",
      deliveryStatus: message.deliveryStatus,
      sentAt: message.sentAt.toISOString(),
    });
    messagesByConversation.set(message.conversationId, group);
  }

  const conversationData: ConversationRecord[] = conversationRows.map(({ conversation, customer }) => ({
    id: conversation.id,
    customerId: customer?.id ?? 0,
    customerName: customer?.name ?? "Contacto nuevo",
    phone: customer?.phone ?? "",
    channel: conversation.channel,
    status: conversation.status,
    assignee: conversation.assignee ?? "Sin asignar",
    unreadCount: conversation.unreadCount,
    lastMessageAt: conversation.lastMessageAt.toISOString(),
    messages: messagesByConversation.get(conversation.id) ?? [],
  }));

  return {
    workOrders: workOrderData,
    customers: customerData,
    vehicles: vehicleData,
    appointments: appointmentData,
    parts: partData,
    conversations: conversationData,
  };
}
