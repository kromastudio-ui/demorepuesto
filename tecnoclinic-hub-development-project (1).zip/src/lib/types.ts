export type WorkOrderStatus =
  | "por_cotizar"
  | "cita_agendada"
  | "diagnostico"
  | "esperando_repuesto"
  | "listo_entrega"
  | "entregado";

export type WorkOrderRecord = {
  id: number;
  code: string;
  customerId: number;
  clientName: string;
  phone: string;
  vehicleId: number | null;
  vehicle: string;
  plate: string;
  service: string;
  description: string;
  status: WorkOrderStatus;
  priority: string;
  technician: string;
  amount: number;
  createdAt: string;
  updatedAt: string;
};

export type CustomerRecord = {
  id: number;
  name: string;
  phone: string;
  email: string;
  notes: string;
  vehicles: { id: number; make: string; model: string; year: number | null; plate: string }[];
  lastInteraction: string;
};

export type VehicleRecord = {
  id: number;
  customerId: number;
  customerName: string;
  phone: string;
  make: string;
  model: string;
  year: number | null;
  plate: string;
  color: string;
};

export type AppointmentRecord = {
  id: number;
  customerId: number;
  customerName: string;
  phone: string;
  vehicleId: number | null;
  vehicle: string;
  plate: string;
  service: string;
  startsAt: string;
  durationMinutes: number;
  status: string;
  notes: string;
  assignedTo: string;
};

export type PartRecord = {
  id: number;
  sku: string;
  name: string;
  brand: string;
  category: string;
  stock: number;
  minimumStock: number;
  price: number;
  supplier: string;
};

export type MessageRecord = {
  id: number;
  conversationId: number;
  body: string;
  direction: "incoming" | "outgoing" | "system";
  author: string;
  deliveryStatus: string;
  sentAt: string;
};

export type ConversationRecord = {
  id: number;
  customerId: number;
  customerName: string;
  phone: string;
  channel: string;
  status: string;
  assignee: string;
  unreadCount: number;
  lastMessageAt: string;
  messages: MessageRecord[];
};

export type DashboardData = {
  workOrders: WorkOrderRecord[];
  customers: CustomerRecord[];
  vehicles: VehicleRecord[];
  appointments: AppointmentRecord[];
  parts: PartRecord[];
  conversations: ConversationRecord[];
};
