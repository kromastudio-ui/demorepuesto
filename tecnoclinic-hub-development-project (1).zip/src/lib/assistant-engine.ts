import { asc, gt } from "drizzle-orm";
import { db } from "@/db";
import { appointments, parts } from "@/db/schema";

const SYSTEM_PROMPT = `Eres el asistente de atención al cliente de Tecnoclinic Repuestos (@tecnoclinicrepuestos), taller y tienda automotriz en Maripérez, Caracas, Venezuela. Atiendes por WhatsApp en español venezolano, con tono cordial, preciso y breve. El taller ofrece limpieza y diagnóstico de inyectores en laboratorio, escáner computarizado y mecánica rápida. El catálogo incluye repuestos ACDelco, lubricantes, filtros y bujías. Usa exclusivamente la disponibilidad y los precios proporcionados en el contexto; nunca inventes inventario, montos, tasas de cambio ni una cita confirmada. Zona horaria America/Caracas. Horario de referencia: lunes a viernes 8:00 a. m.–5:00 p. m. y sábado 8:00 a. m.–1:00 p. m. Dirección: Maripérez, Caracas. Para confirmar una cita solicita nombre, teléfono, vehículo, servicio y fecha/hora; si faltan datos, pregunta solo lo necesario. No afirmes que agendaste una cita a menos que el sistema confirme su creación.`;

function localReply(message: string, inventory: { name: string; brand: string; stock: number; price: number }[]) {
  const normalized = message.toLocaleLowerCase("es-VE");
  const relevant = inventory.filter((item) => {
    const words = `${item.name} ${item.brand}`.toLocaleLowerCase("es-VE").split(/\W+/).filter((word) => word.length > 3);
    return words.some((word) => normalized.includes(word));
  });

  if (/precio|costo|stock|disponib|tienen|hay\s/.test(normalized) && relevant.length) {
    return relevant
      .map((item) => `${item.name} (${item.brand}): ${item.stock > 0 ? `${item.stock} en existencia` : "sin existencia al momento"}${item.stock > 0 ? `, desde $${item.price.toFixed(2)}` : ""}.`)
      .join(" ");
  }
  if (/cita|agend|reserv|disponibilidad/.test(normalized)) {
    return "¡Claro! Con gusto te ayudamos a coordinar una cita en nuestro taller de Maripérez. Compárteme tu nombre, teléfono, vehículo, servicio que necesitas y el día/hora que prefieres. Te confirmaremos disponibilidad antes de dejarla reservada. 🗓️";
  }
  if (/inyector/.test(normalized)) {
    return "En Tecnoclinic contamos con laboratorio para limpieza y diagnóstico de inyectores, con prueba de caudal. El costo depende del vehículo y del diagnóstico; si me indicas marca, modelo y año, te orientamos. Estamos en Maripérez, Caracas. 🔧";
  }
  if (/esc[aá]ner|diagn[oó]stic|check engine/.test(normalized)) {
    return "Realizamos escáner computarizado y diagnóstico de motor en Maripérez. Para orientarte mejor, cuéntame la marca, modelo, año y qué testigo o síntoma presenta tu vehículo. 🔍";
  }
  return "¡Hola! Soy el asistente de Tecnoclinic. Te puedo ayudar con disponibilidad y cotización de repuestos, limpieza de inyectores, escáner computarizado, mecánica rápida o una cita en Maripérez. ¿Qué necesitas para tu vehículo? 🚘";
}

export async function answerCustomerQuestion(message: string, customerName?: string) {
  const [partsRows, upcomingRows] = await Promise.all([
    db.select().from(parts).orderBy(asc(parts.name)),
    db.select({ service: appointments.service, startsAt: appointments.startsAt, status: appointments.status })
      .from(appointments)
      .where(gt(appointments.startsAt, new Date()))
      .orderBy(asc(appointments.startsAt))
      .limit(5),
  ]);
  const inventory = partsRows.map((item) => ({ name: item.name, brand: item.brand, stock: item.stock, price: Number(item.price ?? 0) }));
  const localAnswer = localReply(message, inventory);
  const apiKey = process.env.LLM_ROUTER_API_KEY || process.env.OPENROUTER_API_KEY || process.env.OPENAI_API_KEY;
  if (!apiKey) return localAnswer;

  const isOpenRouter = Boolean(process.env.OPENROUTER_API_KEY || process.env.LLM_ROUTER_API_KEY);
  const endpoint = process.env.LLM_ROUTER_BASE_URL || (isOpenRouter ? "https://openrouter.ai/api/v1/chat/completions" : "https://api.openai.com/v1/chat/completions");
  const model = process.env.LLM_ROUTER_MODEL || (isOpenRouter ? "openai/gpt-4o-mini" : "gpt-4o-mini");
  const inventoryContext = inventory.map((item) => `${item.name} | ${item.brand} | existencia ${item.stock} | precio de referencia $${item.price.toFixed(2)}`).join("\n") || "Sin referencias cargadas.";
  const scheduleContext = upcomingRows.map((item) => `${item.startsAt.toISOString()}: ${item.service} (${item.status})`).join("\n") || "Sin citas futuras registradas.";

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        ...(isOpenRouter ? { "HTTP-Referer": "https://tecnoclinic.local", "X-Title": "TecnoClinic Hub" } : {}),
      },
      body: JSON.stringify({
        model,
        temperature: 0.4,
        messages: [
          { role: "system", content: `${SYSTEM_PROMPT}\n\nINVENTARIO ACTUAL:\n${inventoryContext}\n\nAGENDA PRÓXIMA:\n${scheduleContext}` },
          { role: "user", content: `${customerName ? `Cliente: ${customerName}\n` : ""}${message}` },
        ],
      }),
      signal: AbortSignal.timeout(18_000),
    });
    if (!response.ok) {
      console.warn("LLM Router respondió:", response.status, await response.text());
      return localAnswer;
    }
    const payload = (await response.json()) as { choices?: { message?: { content?: string } }[] };
    return payload.choices?.[0]?.message?.content?.trim() || localAnswer;
  } catch (error) {
    console.warn("LLM Router no disponible; usando respuesta local:", error);
    return localAnswer;
  }
}
